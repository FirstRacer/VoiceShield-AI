# VoiceShield AI - Real W2V2-AASIST Inference Backend

This service provides genuine deep learning inference for voice deepfake and anti-spoofing detection.

## Architecture
- **Frontend**: Wav2Vec 2.0 XLS-R 300M (`facebook/wav2vec2-xls-r-300m`)
- **Backend**: AASIST (Audio Anti-Spoofing using Integrated Spectro-Temporal Graph Attention Networks)
- **Input Spec**: 16 kHz Mono Audio, 64,600 samples (~4.0375 seconds)
- **Output Classes**:
  - `Index 0`: Spoof (Synthetic / Cloned voice)
  - `Index 1`: Bona Fide (Genuine human speech)
- **Formula**:
  - `P(Bona Fide) = softmax(logit_1)`
  - `P(Spoof) = softmax(logit_0)`
  - `Synthetic Risk = P(Spoof) * 100`

## Requirements
- Python 3.10+
- PyTorch 2.0+ with CUDA (recommended) or CPU
- 4GB+ GPU VRAM (or 8GB+ System RAM for CPU)

## How to Set Up & Run

### 1. Install Dependencies
```bash
pip install -r requirements.txt
```

### 2. Download Model Weights
Obtain the trained `w2v2_aasist.pth` checkpoint (from the ASVspoof 2021 / SpeechAntiSpoofingBenchmarks repository or Hugging Face):
```bash
mkdir -p /models
# Download your w2v2_aasist.pth checkpoint to /models/w2v2_aasist.pth
# Alternatively set export MODEL_PATH="/path/to/your/w2v2_aasist.pth"
```

### 3. Start the FastAPI Service
```bash
uvicorn main:app --host 0.0.0.0 --port 8000
```

### 4. Connect VoiceShield AI
In the VoiceShield AI web interface:
1. Open **Detection Settings** (or set `FASTAPI_API_BASE_URL` in `.env`).
2. Set the backend URL to: `http://localhost:8000` (or your remote GPU server URL).
3. Click **Test Real Model Connection** to verify that the status reports:
   `REAL MODEL: ONLINE`
