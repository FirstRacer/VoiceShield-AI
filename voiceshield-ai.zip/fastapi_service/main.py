"""
VoiceShield AI - Real W2V2-AASIST Python/FastAPI Inference Backend
Provides high-throughput neural inference for voice deepfake detection.
Endpoints:
  - GET  /api/health        -> Returns real model runtime status & device
  - GET  /api/model-info    -> Returns model architecture & weight status
  - POST /api/analyze-chunk -> Genuine W2V2-AASIST inference on audio chunk
  - POST /api/analyze-audio -> Multi-window analysis on uploaded audio file
"""

import os
import io
import base64
import wave
import logging
from typing import Optional, List
import numpy as np
import torch

from fastapi import FastAPI, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

# Local model module
from model import (
    W2V2_AASIST,
    compute_w2v2_aasist_prediction,
    TARGET_SAMPLE_RATE,
    WINDOW_SAMPLES,
)

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger("VoiceShield-Inference")

app = FastAPI(
    title="VoiceShield AI - W2V2-AASIST Inference Backend",
    version="1.0.0",
    description="Real voice anti-spoofing and deepfake detection service powered by W2V2-AASIST."
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ---------------------------------------------------------------------------
# Global State & Model Initialization
# ---------------------------------------------------------------------------

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
MODEL_PATH = os.getenv("MODEL_PATH", "/models/w2v2_aasist.pth")
W2V2_MODEL_NAME = os.getenv("W2V2_MODEL_NAME", "facebook/wav2vec2-xls-r-300m")

w2v2_aasist_model: Optional[W2V2_AASIST] = None
is_model_loaded: bool = False
model_load_error: Optional[str] = None


@app.on_event("startup")
def startup_event():
    global w2v2_aasist_model, is_model_loaded, model_load_error
    logger.info(f"Checking for W2V2-AASIST model weights at: {MODEL_PATH}")
    logger.info(f"Target compute device: {DEVICE}")

    try:
        # Check if local checkpoint exists
        if os.path.exists(MODEL_PATH):
            logger.info(f"Found model checkpoint at {MODEL_PATH}. Initializing W2V2-AASIST...")
            model = W2V2_AASIST(w2v2_model_name=W2V2_MODEL_NAME)
            model.load_frontend(DEVICE)

            checkpoint = torch.load(MODEL_PATH, map_location=DEVICE)
            if "state_dict" in checkpoint:
                model.backend.load_state_dict(checkpoint["state_dict"])
            elif "model" in checkpoint:
                model.backend.load_state_dict(checkpoint["model"])
            else:
                model.backend.load_state_dict(checkpoint)

            model.to(DEVICE)
            model.eval()
            w2v2_aasist_model = model
            is_model_loaded = True
            logger.info("W2V2-AASIST model loaded successfully and ready for inference.")
        else:
            model_load_error = f"Model weights not found at '{MODEL_PATH}'."
            logger.warning(
                f"[VoiceShield] {model_load_error}. "
                "Real model inference will report 'REAL_DETECTION_BACKEND_UNAVAILABLE' "
                "until weights are provided. VoiceShield AI strictly forbids faking detections."
            )
    except Exception as e:
        model_load_error = str(e)
        logger.error(f"Failed to load W2V2-AASIST model: {e}")


# ---------------------------------------------------------------------------
# Request / Response Schemas
# ---------------------------------------------------------------------------

class AnalyzeChunkRequest(BaseModel):
    audioBase64: str = Field(..., description="Base64-encoded WAV/PCM audio stream")
    mimeType: Optional[str] = "audio/wav"
    chunkId: int = Field(default=1, description="Sequential chunk index")
    energyLevel: Optional[float] = 0.05
    isSilence: Optional[bool] = False


class AnalyzeAudioFileRequest(BaseModel):
    audioBase64: str = Field(..., description="Base64-encoded complete audio file")
    fileName: Optional[str] = "audio_input.wav"


# ---------------------------------------------------------------------------
# Helper: Decode Base64 WAV/PCM to 16 kHz Mono Float32 Array
# ---------------------------------------------------------------------------

def decode_audio_payload(audio_b64: str) -> np.ndarray:
    """Decodes base64 WAV payload and converts to 16 kHz mono Float32 numpy array"""
    try:
        clean_b64 = audio_b64
        if "," in clean_b64:
            clean_b64 = clean_b64.split(",", 1)[1]

        raw_bytes = base64.b64decode(clean_b64)
        if len(raw_bytes) < 44:
            raise ValueError("Audio buffer too short to contain valid WAV header.")

        with io.BytesIO(raw_bytes) as bio:
            with wave.open(bio, "rb") as wf:
                num_channels = wf.getnchannels()
                sample_width = wf.getsampwidth()
                framerate = wf.getframerate()
                n_frames = wf.getnframes()
                raw_frames = wf.readframes(n_frames)

                if sample_width == 2:
                    dtype = np.int16
                    scale = 32768.0
                elif sample_width == 1:
                    dtype = np.uint8
                    scale = 128.0
                elif sample_width == 4:
                    dtype = np.int32
                    scale = 2147483648.0
                else:
                    raise ValueError(f"Unsupported sample width: {sample_width}")

                audio_data = np.frombuffer(raw_frames, dtype=dtype).astype(np.float32)
                if sample_width == 1:
                    audio_data = (audio_data - 128.0) / scale
                else:
                    audio_data = audio_data / scale

                if num_channels > 1:
                    audio_data = audio_data.reshape(-1, num_channels).mean(axis=1)

                # Resample to 16 kHz if necessary
                if framerate != TARGET_SAMPLE_RATE and len(audio_data) > 0:
                    import scipy.signal
                    num_target_samples = int(len(audio_data) * (TARGET_SAMPLE_RATE / framerate))
                    audio_data = scipy.signal.resample(audio_data, num_target_samples)

                return audio_data

    except Exception as e:
        logger.error(f"Error decoding audio payload: {e}")
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid audio format or corrupt base64 payload: {str(e)}"
        )


# ---------------------------------------------------------------------------
# API Endpoints
# ---------------------------------------------------------------------------

@app.get("/health")
@app.get("/api/health")
def health_check():
    """Returns backend health and whether the real model is online."""
    online = bool(is_model_loaded and w2v2_aasist_model is not None)
    return {
        "status": "ONLINE" if online else "OFFLINE",
        "service": "VoiceShield AI W2V2-AASIST Inference Backend",
        "realModelOnline": online,
        "modelLoaded": online,
        "pytorchLoaded": True,
        "weightsLoaded": online,
        "device": str(DEVICE),
        "modelPath": MODEL_PATH,
        "modelName": "SpeechAntiSpoofingBenchmarks/W2V2-AASIST",
        "error": model_load_error if not online else None
    }


@app.get("/model-info")
@app.get("/api/model-info")
def model_info():
    """Detailed technical specification of the anti-spoofing model."""
    return {
        "modelName": "SpeechAntiSpoofingBenchmarks/W2V2-AASIST",
        "architecture": "Wav2Vec 2.0 (XLS-R 300M) + AASIST Graph Attention Network",
        "classes": {
            "0": "Spoof (Synthetic / Cloned Speech)",
            "1": "Bona Fide (Genuine Human Speech)"
        },
        "targetSampleRate": TARGET_SAMPLE_RATE,
        "windowSamples": WINDOW_SAMPLES,
        "device": str(DEVICE),
        "status": "ONLINE" if is_model_loaded else "OFFLINE",
        "weightsAvailable": is_model_loaded,
        "conversionFormula": "syntheticProbability = softmax(logit_spoof) * 100",
    }


@app.post("/analyze-chunk")
@app.post("/api/analyze-chunk")
def analyze_chunk(req: AnalyzeChunkRequest):
    """
    Executes actual W2V2-AASIST inference on incoming audio chunk.
    If the model is unavailable, strictly returns REAL_DETECTION_BACKEND_UNAVAILABLE.
    """
    if not is_model_loaded or w2v2_aasist_model is None:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail={
                "success": False,
                "error": "REAL_DETECTION_BACKEND_UNAVAILABLE",
                "message": (
                    f"Real W2V2-AASIST model is offline. Model weights missing at '{MODEL_PATH}'. "
                    "VoiceShield AI strictly prohibits fabricated detection results."
                ),
                "modelStatus": "OFFLINE",
                "chunkId": req.chunkId,
            }
        )

    # Decode audio
    samples = decode_audio_payload(req.audioBase64)
    if len(samples) == 0:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"success": False, "error": "EMPTY_AUDIO", "message": "Audio contains no samples."}
        )

    # Check acoustic RMS silence
    rms = float(np.sqrt(np.mean(samples ** 2)))
    if rms < 0.005 or req.isSilence:
        return {
            "success": True,
            "chunkId": req.chunkId,
            "isSilence": True,
            "energyLevel": round(rms, 4),
            "syntheticProbability": 0.0,
            "bonaFideProbability": 100.0,
            "spoofProbability": 0.0,
            "confidence": 30.0,
            "riskLevel": "LOW",
            "source": "Acoustic Silence Gate",
            "note": "Below acoustic energy speech threshold (Silence)",
        }

    try:
        # Run REAL Model Inference
        pred = compute_w2v2_aasist_prediction(w2v2_aasist_model, samples, DEVICE)

        return {
            "success": True,
            "chunkId": req.chunkId,
            "isSilence": False,
            "energyLevel": round(rms, 4),
            "syntheticProbability": pred["syntheticProbability"],
            "bonaFideProbability": pred["bonaFideProbability"],
            "spoofProbability": pred["spoofProbability"],
            "confidence": pred["confidence"],
            "riskLevel": pred["riskLevel"],
            "rawLogits": pred["rawLogits"],
            "source": pred["source"],
            "windowSamples": pred["windowSamples"],
        }
    except Exception as e:
        logger.error(f"Inference error on chunk {req.chunkId}: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={
                "success": False,
                "error": "INFERENCE_FAILED",
                "message": f"Real model inference failed: {str(e)}",
                "chunkId": req.chunkId,
            }
        )


@app.post("/analyze-audio")
@app.post("/api/analyze-audio")
def analyze_audio_file(req: AnalyzeAudioFileRequest):
    """
    Multi-window W2V2-AASIST evaluation across complete audio file.
    Aggregates window probabilities using trimmed mean.
    """
    if not is_model_loaded or w2v2_aasist_model is None:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail={
                "success": False,
                "error": "REAL_DETECTION_BACKEND_UNAVAILABLE",
                "message": (
                    f"Real W2V2-AASIST model is offline. Model weights missing at '{MODEL_PATH}'. "
                    "VoiceShield AI strictly prohibits fabricated detection results."
                ),
                "modelStatus": "OFFLINE",
            }
        )

    samples = decode_audio_payload(req.audioBase64)
    if len(samples) == 0:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"success": False, "error": "EMPTY_AUDIO", "message": "File contains no audio samples."}
        )

    # Slice into 4-second windows with 2-second hop (overlap)
    hop_size = 32000 # 2 seconds at 16 kHz
    window_size = WINDOW_SAMPLES # 64,600 samples (~4.03s)

    if len(samples) <= window_size:
        windows = [samples]
    else:
        windows = []
        for start in range(0, len(samples) - hop_size, hop_size):
            end = min(len(samples), start + window_size)
            windows.append(samples[start:end])
            if end >= len(samples):
                break

    chunk_results = []
    probabilities = []
    confidences = []

    for idx, win in enumerate(windows):
        pred = compute_w2v2_aasist_prediction(w2v2_aasist_model, win, DEVICE)
        chunk_results.append({
            "chunkId": idx + 1,
            "syntheticProbability": pred["syntheticProbability"],
            "bonaFideProbability": pred["bonaFideProbability"],
            "spoofProbability": pred["spoofProbability"],
            "confidence": pred["confidence"],
            "riskLevel": pred["riskLevel"],
            "rawLogits": pred["rawLogits"],
        })
        probabilities.append(pred["syntheticProbability"])
        confidences.append(pred["confidence"])

    # Robust Trimmed Mean Aggregation
    if len(probabilities) >= 4:
        sorted_probs = sorted(probabilities)
        trimmed = sorted_probs[1:-1] # Discard min and max outliers
        final_score = round(float(np.mean(trimmed)), 1)
    else:
        final_score = round(float(np.mean(probabilities)), 1)

    avg_confidence = round(float(np.mean(confidences)), 1)
    final_risk = "HIGH" if final_score >= 65.0 else ("MEDIUM" if final_score >= 35.0 else "LOW")

    return {
        "success": True,
        "syntheticProbability": final_score,
        "rollingAvg": final_score,
        "riskLevel": final_risk,
        "confidence": avg_confidence,
        "bonaFideProbability": round(100.0 - final_score, 1),
        "spoofProbability": round(final_score / 100.0, 4),
        "chunks": chunk_results,
        "totalWindows": len(windows),
        "fileName": req.fileName,
        "source": "W2V2-AASIST Neural Pipeline",
    }
