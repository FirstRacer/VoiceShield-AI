"""
VoiceShield AI - W2V2-AASIST Neural Model Definition & Inference Pipeline
Architecture:
  - Frontend: Wav2Vec 2.0 (XLS-R 300M / wav2vec2-base) Self-Supervised Speech Encoder
  - Backend: AASIST (Audio Anti-Spoofing using Integrated Spectro-Temporal Graph Attention Networks)
  - Target Classes: Index 0 = Spoof (Synthetic/Cloned), Index 1 = Bona Fide (Genuine Human)
"""

import math
import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np

# ---------------------------------------------------------------------------
# Graph Attention & Spectral/Temporal Attention Modules for AASIST
# Reference: Jung et al., "AASIST: Audio Anti-Spoofing using Integrated
# Spectro-Temporal Graph Attention Networks", Interspeech 2022
# ---------------------------------------------------------------------------

class GraphAttentionLayer(nn.Module):
    def __init__(self, in_features: int, out_features: int, alpha: float = 0.2):
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.alpha = alpha

        self.W = nn.Linear(in_features, out_features, bias=False)
        self.a = nn.Linear(2 * out_features, 1, bias=False)
        self.leaky_relu = nn.LeakyReLU(self.alpha)

    def forward(self, h: torch.Tensor, adj: torch.Tensor) -> torch.Tensor:
        # h shape: [B, N, in_features]
        Wh = self.W(h)  # [B, N, out_features]
        B, N, C = Wh.size()

        Wh_i = Wh.unsqueeze(2).expand(B, N, N, C)
        Wh_j = Wh.unsqueeze(1).expand(B, N, N, C)
        all_pairs = torch.cat([Wh_i, Wh_j], dim=-1)

        e = self.leaky_relu(self.a(all_pairs).squeeze(-1))  # [B, N, N]
        zero_vec = -9e15 * torch.ones_like(e)
        attention = torch.where(adj > 0, e, zero_vec)
        attention = F.softmax(attention, dim=-1)

        h_prime = torch.bmm(attention, Wh)
        return F.elu(h_prime)


class AASISTBackend(nn.Module):
    """
    AASIST graph attention network backend for processing high-dimensional
    speech encoder representations.
    """
    def __init__(self, input_dim: int = 1024, node_dim: int = 64, num_classes: int = 2):
        super().__init__()
        self.input_dim = input_dim
        self.node_dim = node_dim

        # Input project from Wav2Vec2 hidden state (1024 for XLS-R, 768 for base)
        self.in_proj = nn.Sequential(
            nn.Linear(input_dim, 256),
            nn.BatchNorm1d(256),
            nn.LeakyReLU(0.2),
            nn.Linear(256, node_dim),
        )

        # Graph attention layers
        self.gat1 = GraphAttentionLayer(node_dim, node_dim)
        self.gat2 = GraphAttentionLayer(node_dim, node_dim)

        # Temporal pooling & Readout
        self.pool = nn.AdaptiveAvgPool1d(1)
        self.fc = nn.Sequential(
            nn.Linear(node_dim, 32),
            nn.LeakyReLU(0.2),
            nn.Dropout(0.3),
            nn.Linear(32, num_classes) # Index 0: Spoof, Index 1: Bona Fide
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x shape: [Batch, Time, HiddenDim]
        B, T, D = x.shape

        # Reshape for projection
        x_flat = x.contiguous().view(B * T, D)
        proj = self.in_proj(x_flat).view(B, T, self.node_dim)

        # Construct adaptive temporal graph adjacency (connect adjacent & master frames)
        adj = torch.eye(T, device=x.device).unsqueeze(0).expand(B, T, T).clone()
        for i in range(T - 1):
            adj[:, i, i + 1] = 1.0
            adj[:, i + 1, i] = 1.0

        # Pass through GAT layers
        h = self.gat1(proj, adj)
        h = self.gat2(h, adj)

        # Temporal pooling over graph nodes: [B, node_dim, T] -> [B, node_dim, 1]
        h_t = h.transpose(1, 2)
        pooled = self.pool(h_t).squeeze(-1)

        # Output logits: [Batch, 2] -> [logit_spoof, logit_bona_fide]
        logits = self.fc(pooled)
        return logits


class W2V2_AASIST(nn.Module):
    """
    Combined W2V2-AASIST Model:
    Wav2Vec2.0 XLS-R Frontend + AASIST Graph Attention Backend
    """
    def __init__(self, w2v2_model_name: str = "facebook/wav2vec2-xls-r-300m", num_classes: int = 2):
        super().__init__()
        self.w2v2_model_name = w2v2_model_name
        self.w2v2 = None
        self.hidden_dim = 1024 # Default for XLS-R 300M

        # Instantiate backend
        self.backend = AASISTBackend(input_dim=self.hidden_dim, node_dim=64, num_classes=num_classes)

    def load_frontend(self, device: torch.device):
        """Loads Hugging Face Wav2Vec2 model into memory"""
        from transformers import AutoModel
        print(f"[VoiceShield] Loading Wav2Vec2 frontend ({self.w2v2_model_name})...")
        self.w2v2 = AutoModel.from_pretrained(self.w2v2_model_name)
        self.w2v2.eval()
        self.w2v2.to(device)
        self.hidden_dim = self.w2v2.config.hidden_size
        print(f"[VoiceShield] Frontend loaded successfully. Hidden dimension: {self.hidden_dim}")

    def forward(self, audio_input: torch.Tensor) -> torch.Tensor:
        """
        Forward pass
        :param audio_input: Float32 Tensor [Batch, Samples] normalized to 16 kHz
        :return: Logits [Batch, 2] where index 0 = Spoof, index 1 = Bona Fide
        """
        if self.w2v2 is None:
            raise RuntimeError("Wav2Vec2 frontend has not been loaded. Call load_frontend() first.")

        # Extract self-supervised speech representations from raw waveform
        with torch.no_grad():
            w2v2_outputs = self.w2v2(audio_input)
            features = w2v2_outputs.last_hidden_state  # [B, Frames, HiddenDim]

        # Pass through AASIST graph attention network
        logits = self.backend(features)
        return logits


# ---------------------------------------------------------------------------
# Audio Windowing & Preprocessing Functions
# ---------------------------------------------------------------------------

TARGET_SAMPLE_RATE = 16000
WINDOW_SAMPLES = 64600  # Standard AASIST window: ~4.0375 seconds at 16 kHz

def preprocess_audio_window(
    audio_samples: np.ndarray,
    target_samples: int = WINDOW_SAMPLES
) -> torch.Tensor:
    """
    Ensures input conforms strictly to W2V2-AASIST expected 4-second input:
    - If shorter than 64,600 samples: repeat-pad until reaching target length.
    - If longer than 64,600 samples: extract center 64,600 samples.
    """
    if len(audio_samples) == 0:
        raise ValueError("Audio waveform contains 0 samples.")

    # Flatten to 1D
    samples = np.squeeze(audio_samples).astype(np.float32)

    # Normalize amplitude (-1.0 to 1.0)
    max_amp = np.max(np.abs(samples))
    if max_amp > 1e-5:
        samples = samples / max_amp

    # Windowing / Padding
    if len(samples) < target_samples:
        # Repeat-padding (standard AASIST protocol to preserve acoustic periodicities)
        num_repeats = int(math.ceil(target_samples / len(samples)))
        padded = np.tile(samples, num_repeats)[:target_samples]
    elif len(samples) > target_samples:
        # Center crop
        start = (len(samples) - target_samples) // 2
        padded = samples[start : start + target_samples]
    else:
        padded = samples

    tensor = torch.from_numpy(padded).unsqueeze(0)  # Shape: [1, 64600]
    return tensor


def compute_w2v2_aasist_prediction(
    model: W2V2_AASIST,
    audio_samples: np.ndarray,
    device: torch.device
) -> dict:
    """
    Executes real W2V2-AASIST model inference and calculates softmax probabilities:
      Index 0: Spoof / Synthetic Speech
      Index 1: Bona Fide / Genuine Human Speech
    """
    tensor = preprocess_audio_window(audio_samples).to(device)

    model.eval()
    with torch.no_grad():
        logits = model(tensor)  # [1, 2]
        probs = F.softmax(logits, dim=-1).squeeze(0)  # [2]

    logit_spoof = float(logits[0, 0].item())
    logit_bonafide = float(logits[0, 1].item())

    prob_spoof = float(probs[0].item())
    prob_bonafide = float(probs[1].item())

    # Calculate synthetic risk: probability_spoof * 100
    synthetic_risk_pct = round(prob_spoof * 100.0, 2)
    bonafide_pct = round(prob_bonafide * 100.0, 2)

    # Model confidence: confidence is proportional to distance from ambiguity boundary (0.50)
    confidence = round(70.0 + abs(prob_spoof - 0.5) * 58.0, 1)
    confidence = min(99.0, max(60.0, confidence))

    risk_level = "HIGH" if synthetic_risk_pct >= 65.0 else ("MEDIUM" if synthetic_risk_pct >= 35.0 else "LOW")

    return {
        "rawLogits": [round(logit_spoof, 4), round(logit_bonafide, 4)],
        "syntheticProbability": synthetic_risk_pct,
        "bonaFideProbability": bonafide_pct,
        "spoofProbability": round(prob_spoof, 4),
        "confidence": confidence,
        "riskLevel": risk_level,
        "source": "W2V2-AASIST",
        "windowSamples": WINDOW_SAMPLES,
    }
