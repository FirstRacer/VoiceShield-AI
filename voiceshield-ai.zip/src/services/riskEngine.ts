/**
 * VoiceShield AI - Rolling Risk Engine
 * Aggregates genuine W2V2-AASIST model inference predictions across temporal windows.
 * Zero simulation: All probabilities and risk scores originate strictly from genuine model logits.
 */

import { RiskLevel, AudioChunkResult, DetectionSettings } from '../types';

export const DEFAULT_SETTINGS: DetectionSettings = {
  lowThreshold: 35,
  highThreshold: 65,
  rollingWindowSize: 5,
  chunkDurationSeconds: 1.5,
  apiBaseUrl: import.meta.env.VITE_API_BASE_URL || '',
  sensitivity: 'Standard',
};

/**
 * Model Output Semantics Conversion (SpeechAntiSpoofingBenchmarks/W2V2-AASIST):
 * W2V2-AASIST evaluates 16 kHz audio and outputs 2-class logits [logit_spoof, logit_bona_fide].
 * Class index 0: Spoof / Synthetic / Cloned speech
 * Class index 1: Bona Fide / Genuine human speech
 *
 * Softmax over logits:
 *   prob_spoof = exp(logit_0) / (exp(logit_0) + exp(logit_1))
 *   prob_bonafide = exp(logit_1) / (exp(logit_0) + exp(logit_1))
 *   synthetic_risk_percent = prob_spoof * 100
 */
export function convertW2V2LogitsToSyntheticRisk(logitSpoof: number, logitBonaFide: number): number {
  const maxLogit = Math.max(logitSpoof, logitBonaFide);
  const expSpoof = Math.exp(logitSpoof - maxLogit);
  const expBonaFide = Math.exp(logitBonaFide - maxLogit);
  const probSpoof = expSpoof / (expSpoof + expBonaFide);
  return Math.round(probSpoof * 1000) / 10;
}

export function convertBonaFideProbToSyntheticRisk(bonaFideProb: number): number {
  const bounded = Math.max(0, Math.min(1, bonaFideProb));
  return Math.round((1 - bounded) * 1000) / 10;
}

/**
 * Calculates risk level based on thresholds
 * LOW: below 35%
 * MEDIUM: 35% to below 65%
 * HIGH: 65% and above
 */
export function calculateRiskLevel(
  probabilityPercent: number,
  lowThreshold = 35,
  highThreshold = 65
): RiskLevel {
  if (probabilityPercent < lowThreshold) {
    return 'LOW';
  } else if (probabilityPercent < highThreshold) {
    return 'MEDIUM';
  }
  return 'HIGH';
}

export interface AggregatedRiskResult {
  isReady: boolean;
  score: number | null; // null if still analyzing or backend offline
  riskLevel: RiskLevel;
  confidence: number;
  validChunkCount: number;
  totalChunkCount: number;
  statusText: string;
}

/**
 * Calculates ONE dynamic overall risk score from ACTUAL model predictions.
 * Uses a robust trimmed-mean aggregation across valid speech chunks with genuine model outputs.
 * Does NOT generate fake scores. If insufficient chunks or backend offline, returns score: null.
 */
export function calculateAggregatedOverallRisk(
  chunks: AudioChunkResult[],
  lowThreshold = 35,
  highThreshold = 65,
  minValidChunks = 1,
  backendConnected = true
): AggregatedRiskResult {
  const totalChunkCount = chunks.length;

  if (!backendConnected) {
    return {
      isReady: false,
      score: null,
      riskLevel: 'LOW',
      confidence: 0,
      validChunkCount: 0,
      totalChunkCount,
      statusText: 'REAL MODEL OFFLINE',
    };
  }

  // Filter for valid speech chunks with actual model evaluations (non-null, non-silence)
  const validSpeechChunks = chunks.filter(
    (c) => !c.isSilence && c.syntheticProbability !== null && typeof c.syntheticProbability === 'number'
  );

  if (validSpeechChunks.length < minValidChunks) {
    return {
      isReady: false,
      score: null,
      riskLevel: 'LOW',
      confidence: 0,
      validChunkCount: validSpeechChunks.length,
      totalChunkCount,
      statusText: 'Analyzing voice…',
    };
  }

  // Robust statistical aggregation:
  // For >= 5 chunks, perform trimmed mean (discard highest and lowest outlier)
  let analysisSet = [...validSpeechChunks];
  if (analysisSet.length >= 5) {
    analysisSet.sort((a, b) => (a.syntheticProbability || 0) - (b.syntheticProbability || 0));
    analysisSet = analysisSet.slice(1, analysisSet.length - 1);
  }

  let totalWeight = 0;
  let weightedSum = 0;
  let confidenceSum = 0;

  for (const chunk of analysisSet) {
    const prob = chunk.syntheticProbability || 0;
    const energyFactor = Math.min(1.2, 0.6 + (chunk.energyLevel || 0.1));
    const weight = ((chunk.confidence || 75) / 100) * energyFactor;
    weightedSum += prob * weight;
    confidenceSum += chunk.confidence || 75;
    totalWeight += weight;
  }

  const finalScore = totalWeight > 0 ? Math.round((weightedSum / totalWeight) * 10) / 10 : 0;
  const avgConfidence = Math.round((confidenceSum / analysisSet.length) * 10) / 10;
  const level = calculateRiskLevel(finalScore, lowThreshold, highThreshold);

  return {
    isReady: true,
    score: finalScore,
    riskLevel: level,
    confidence: avgConfidence,
    validChunkCount: validSpeechChunks.length,
    totalChunkCount,
    statusText: `${level} RISK`,
  };
}

/**
 * Calculates rolling average across recent valid non-silent chunks
 */
export function calculateRollingAverage(
  chunks: AudioChunkResult[],
  windowSize = 5
): number | null {
  const activeChunks = chunks.filter(
    (c) => !c.isSilence && c.syntheticProbability !== null && typeof c.syntheticProbability === 'number'
  );
  if (activeChunks.length === 0) return null;

  const recent = activeChunks.slice(-windowSize);
  const sum = recent.reduce((acc, curr) => acc + (curr.syntheticProbability || 0), 0);
  return Math.round((sum / recent.length) * 10) / 10;
}

/**
 * Determines the risk trajectory trend: 'RISING', 'FALLING', or 'STABLE'
 */
export function calculateRiskTrend(chunks: AudioChunkResult[]): 'RISING' | 'FALLING' | 'STABLE' {
  const valid = chunks.filter((c) => !c.isSilence && typeof c.syntheticProbability === 'number');
  if (valid.length < 2) return 'STABLE';
  const recent = valid.slice(-4);
  if (recent.length < 2) return 'STABLE';

  const first = recent[0].syntheticProbability || 0;
  const last = recent[recent.length - 1].syntheticProbability || 0;
  const diff = last - first;

  if (diff > 10) return 'RISING';
  if (diff < -10) return 'FALLING';
  return 'STABLE';
}

/**
 * Standard cautious cybersecurity risk wording
 */
export function getRiskExplanation(
  riskLevel: RiskLevel,
  probability: number
): { title: string; explanation: string; recommendation: string } {
  switch (riskLevel) {
    case 'HIGH':
      return {
        title: '⚠️ High Voice Risk Detected',
        explanation: `High synthetic-voice risk detected by W2V2-AASIST neural model (Synthetic Probability: ${probability}%). Multiple audio frames exhibit spectral characteristics of neural vocoders and synthetic voice generation.`,
        recommendation:
          'High synthetic-voice risk detected. Do not share OTPs. Do not reveal passwords or credentials. Do not authorize payments based only on the conversation. Independently confirm important requests through a trusted channel.',
      };
    case 'MEDIUM':
      return {
        title: 'Ambiguous Acoustic Signatures Detected',
        explanation: `Moderate synthetic indicators detected (Synthetic Probability: ${probability}%). Acoustic features may be influenced by cellular compression or background channel distortion.`,
        recommendation:
          'Continue with caution. Do not authorize unverified transactions or share confidential information.',
      };
    case 'LOW':
    default:
      return {
        title: 'No Strong Synthetic Indicators Detected',
        explanation: `Acoustic features align with organic human speech parameters verified by W2V2-AASIST (Synthetic Probability: ${probability}%).`,
        recommendation:
          'Standard precautions still apply for unexpected financial or authentication requests.',
      };
  }
}
