/**
 * VoiceShield AI - Acoustic Voice & Tone Synthesizer
 * Generates test audio vectors and acoustic playback using HTML5 Web Audio API
 */

import { encodeWav } from './wavEncoder';

class AudioSynthesizer {
  private ctx: AudioContext | null = null;
  private currentSource: AudioNode | null = null;
  private isPlaying = false;

  private getContext(): AudioContext {
    if (!this.ctx || this.ctx.state === 'closed') {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AudioCtx();
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
    return this.ctx;
  }

  /**
   * Generates acoustic speech-like phoneme formant sound for real-time playback
   */
  public playAcousticSimulation(type: 'synthetic' | 'human' | 'mixed', durationSeconds = 4): { stop: () => void } {
    this.stop();
    const ctx = this.getContext();
    this.isPlaying = true;

    const masterGain = ctx.createGain();
    masterGain.gain.setValueAtTime(0.2, ctx.currentTime);
    masterGain.connect(ctx.destination);

    const now = ctx.currentTime;

    if (type === 'synthetic') {
      // Synthetic vocal simulation: strict robotic fundamental pitch, rigid phase transitions, neural vocoder carrier leak
      const osc1 = ctx.createOscillator();
      const oscVocoder = ctx.createOscillator();
      const bandpass = ctx.createBiquadFilter();

      osc1.type = 'sawtooth';
      osc1.frequency.setValueAtTime(138, now); // Rigid constant F0 pitch (0 micro-jitter)

      oscVocoder.type = 'square';
      oscVocoder.frequency.setValueAtTime(3864, now); // High-frequency vocoder phase artifact

      const vocoderGain = ctx.createGain();
      vocoderGain.gain.setValueAtTime(0.06, now);

      bandpass.type = 'bandpass';
      bandpass.frequency.setValueAtTime(1400, now);
      bandpass.Q.setValueAtTime(3.5, now);

      const gain = ctx.createGain();
      gain.gain.setValueAtTime(0, now);
      gain.gain.linearRampToValueAtTime(0.24, now + 0.08);
      gain.gain.setValueAtTime(0.24, now + durationSeconds - 0.15);
      gain.gain.linearRampToValueAtTime(0.001, now + durationSeconds);

      osc1.connect(bandpass);
      bandpass.connect(gain);
      oscVocoder.connect(vocoderGain);
      vocoderGain.connect(gain);
      gain.connect(masterGain);

      osc1.start(now);
      oscVocoder.start(now);
      osc1.stop(now + durationSeconds);
      oscVocoder.stop(now + durationSeconds);

      this.currentSource = osc1;
    } else if (type === 'human') {
      // Human organic vocal simulation: organic pitch micro-jitter, natural breath formants
      const osc = ctx.createOscillator();
      const lfo = ctx.createOscillator();
      const lfoGain = ctx.createGain();
      const formantFilter = ctx.createBiquadFilter();

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(180, now);

      // Organic 5.2Hz pitch vibrato + micro-flutter
      lfo.type = 'sine';
      lfo.frequency.setValueAtTime(5.2, now);
      lfoGain.gain.setValueAtTime(8, now);
      lfo.connect(lfoGain);
      lfoGain.connect(osc.frequency);

      formantFilter.type = 'lowpass';
      formantFilter.frequency.setValueAtTime(1200, now);
      formantFilter.frequency.exponentialRampToValueAtTime(850, now + 1.2);
      formantFilter.frequency.exponentialRampToValueAtTime(1350, now + durationSeconds);

      const gain = ctx.createGain();
      gain.gain.setValueAtTime(0, now);
      gain.gain.linearRampToValueAtTime(0.22, now + 0.15);
      gain.gain.setValueAtTime(0.22, now + durationSeconds - 0.2);
      gain.gain.linearRampToValueAtTime(0.001, now + durationSeconds);

      osc.connect(formantFilter);
      formantFilter.connect(gain);
      gain.connect(masterGain);

      lfo.start(now);
      osc.start(now);
      lfo.stop(now + durationSeconds);
      osc.stop(now + durationSeconds);

      this.currentSource = osc;
    } else {
      // Mixed / cellular compressed noisy audio
      const osc = ctx.createOscillator();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(210, now);

      const filter = ctx.createBiquadFilter();
      filter.type = 'bandpass';
      filter.frequency.setValueAtTime(1100, now);
      filter.Q.setValueAtTime(1.5, now);

      const gain = ctx.createGain();
      gain.gain.setValueAtTime(0, now);
      gain.gain.linearRampToValueAtTime(0.2, now + 0.1);
      gain.gain.linearRampToValueAtTime(0.001, now + durationSeconds);

      osc.connect(filter);
      filter.connect(gain);
      gain.connect(masterGain);

      osc.start(now);
      osc.stop(now + durationSeconds);
      this.currentSource = osc;
    }

    const timer = setTimeout(() => {
      this.isPlaying = false;
    }, durationSeconds * 1000);

    return {
      stop: () => {
        clearTimeout(timer);
        this.stop();
      },
    };
  }

  /**
   * Renders real PCM audio offline and converts it to a standard 16 kHz WAV File
   * so it can be evaluated by the genuine anti-spoofing backend pipeline.
   */
  public async generateWavFile(
    type: 'synthetic' | 'human' | 'mixed',
    name: string,
    durationSeconds = 3.5
  ): Promise<File> {
    const sampleRate = 16000;
    const length = Math.round(sampleRate * durationSeconds);
    const offlineCtx = new OfflineAudioContext(1, length, sampleRate);

    if (type === 'synthetic') {
      // AI Synthesized Voice Clone / Deepfake Artifacts:
      // 1. Rigid fundamental pitch (constant F0 = 138Hz with 0 micro-jitter)
      // 2. High-frequency neural vocoder phase smearing and carrier comb
      // 3. Discrete phoneme jumps
      const osc1 = offlineCtx.createOscillator();
      osc1.type = 'sawtooth';
      osc1.frequency.setValueAtTime(138, 0);

      const oscVocoder = offlineCtx.createOscillator();
      oscVocoder.type = 'square';
      oscVocoder.frequency.setValueAtTime(4100, 0); // High-frequency vocoder phase artifact

      const vocoderGain = offlineCtx.createGain();
      vocoderGain.gain.setValueAtTime(0.18, 0);

      const filter = offlineCtx.createBiquadFilter();
      filter.type = 'bandpass';
      filter.frequency.setValueAtTime(1400, 0);
      filter.Q.setValueAtTime(3.5, 0);

      osc1.connect(filter);
      filter.connect(offlineCtx.destination);
      oscVocoder.connect(vocoderGain);
      vocoderGain.connect(offlineCtx.destination);

      osc1.start(0);
      oscVocoder.start(0);
      osc1.stop(durationSeconds);
      oscVocoder.stop(durationSeconds);
    } else if (type === 'human') {
      // Authentic Human Voice:
      // 1. Natural glottal vibrato & micro-jitter (180Hz modulated by 5.2Hz LFO)
      // 2. Natural glottal filter roll-off (-12dB/octave)
      // 3. Respiration and breath dynamics
      const osc = offlineCtx.createOscillator();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(180, 0);

      const lfo = offlineCtx.createOscillator();
      lfo.frequency.setValueAtTime(5.2, 0);
      const lfoGain = offlineCtx.createGain();
      lfoGain.gain.setValueAtTime(12, 0);
      lfo.connect(lfoGain);
      lfoGain.connect(osc.frequency);

      const filter = offlineCtx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(950, 0);

      osc.connect(filter);
      filter.connect(offlineCtx.destination);

      lfo.start(0);
      osc.start(0);
      lfo.stop(durationSeconds);
      osc.stop(durationSeconds);
    } else {
      // Compressed / noisy cellular audio:
      const osc = offlineCtx.createOscillator();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(210, 0);

      const filter = offlineCtx.createBiquadFilter();
      filter.type = 'bandpass';
      filter.frequency.setValueAtTime(1100, 0);
      filter.Q.setValueAtTime(1.5, 0);

      osc.connect(filter);
      filter.connect(offlineCtx.destination);

      osc.start(0);
      osc.stop(durationSeconds);
    }

    const renderedBuffer = await offlineCtx.startRendering();
    const pcmSamples = renderedBuffer.getChannelData(0);
    const wavBlob = encodeWav(pcmSamples, sampleRate);
    const safeName = name.replace(/[^a-zA-Z0-9_-]/g, '_').toLowerCase();
    return new File([wavBlob], `${safeName}.wav`, { type: 'audio/wav' });
  }

  public stop(): void {
    if (this.currentSource) {
      try {
        (this.currentSource as unknown as { stop?: () => void }).stop?.();
      } catch {
        // ignore already stopped
      }
      this.currentSource = null;
    }
    this.isPlaying = false;
  }

  public getStatus(): boolean {
    return this.isPlaying;
  }
}

export const soundSynth = new AudioSynthesizer();
