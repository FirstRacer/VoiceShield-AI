/**
 * Sample Audio Test Clips for VoiceShield AI
 * Reference acoustic scenarios for voice cloning and anti-spoofing verification
 */

export interface SampleAudioClip {
  id: string;
  name: string;
  category: 'Authentic Human' | 'Synthetic Clone' | 'TTS Robocall' | 'Compressed Noisy';
  durationText: string;
  expectedRisk: 'LOW' | 'HIGH' | 'MEDIUM';
  description: string;
  synthesizerType: 'human' | 'synthetic' | 'mixed';
}

export const SAMPLE_AUDIO_CLIPS: SampleAudioClip[] = [
  {
    id: 'sample-human-call',
    name: 'Authentic Human Voice — Natural Conversation',
    category: 'Authentic Human',
    durationText: '4.5s',
    expectedRisk: 'LOW',
    description: 'Natural human vocal tract formants with organic respiratory pauses and authentic F0 pitch variance.',
    synthesizerType: 'human',
  },
  {
    id: 'sample-cloned-banking',
    name: 'Cloned Voice — Urgent Wire Transfer Demand (Deepfake Scenario)',
    category: 'Synthetic Clone',
    durationText: '5.0s',
    expectedRisk: 'HIGH',
    description: 'Neural voice clone scenario containing vocoder phase artifacts and abnormal high-frequency spectral flatness.',
    synthesizerType: 'synthetic',
  },
  {
    id: 'sample-tts-robocall',
    name: 'TTS Robocall — Automated Account Suspension Warning',
    category: 'TTS Robocall',
    durationText: '4.0s',
    expectedRisk: 'HIGH',
    description: 'Concatenative text-to-speech audio with uniform glottal pulses and mechanical rhythm.',
    synthesizerType: 'synthetic',
  },
  {
    id: 'sample-compressed-voip',
    name: 'Compressed Cellular Call — Courier Delivery Agent (Noisy)',
    category: 'Compressed Noisy',
    durationText: '4.2s',
    expectedRisk: 'MEDIUM',
    description: 'Heavy AMR-WB cellular codec quantization noise overlapping acoustic environmental chatter.',
    synthesizerType: 'mixed',
  },
];
