import React, { useState } from 'react';
import { AnalysisSession, RiskLevel } from '../types';
import {
  History as HistoryIcon,
  ShieldCheck,
  ShieldAlert,
  AlertTriangle,
  Info,
  Trash2,
  Download,
  Filter,
  Eye,
  X,
  Lock,
  Layers
} from 'lucide-react';

interface HistoryViewProps {
  sessions: AnalysisSession[];
  onClearHistory: () => void;
  modelStatus?: 'ONLINE' | 'OFFLINE' | 'CHECKING';
}

export const HistoryView: React.FC<HistoryViewProps> = ({
  sessions,
  onClearHistory,
  modelStatus = 'CHECKING',
}) => {
  const [filterRisk, setFilterRisk] = useState<'ALL' | RiskLevel>('ALL');
  const [selectedSession, setSelectedSession] = useState<AnalysisSession | null>(null);

  const filteredSessions = sessions.filter((s) => {
    if (filterRisk === 'ALL') return true;
    return s.riskLevel === filterRisk;
  });

  const exportMetadataJson = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(sessions, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `voiceshield_session_metadata_${Date.now()}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Real Model Offline Notice */}
      {modelStatus !== 'ONLINE' && (
        <div className="p-3.5 rounded-xl bg-amber-50/90 dark:bg-amber-950/40 border border-amber-300 dark:border-amber-800 text-xs text-amber-900 dark:text-amber-200 flex items-center gap-2.5">
          <AlertTriangle className="w-4 h-4 text-amber-600 flex-shrink-0" />
          <span>
            <strong>Real Model Offline:</strong> The W2V2-AASIST neural backend is currently disconnected. Archived session records below are retained for audit inspection only.
          </span>
        </div>
      )}

      {/* Top Banner: Privacy Protection Assurance */}
      <div className="p-4 rounded-xl bg-lime-50/80 dark:bg-lime-950/30 border border-lime-200 dark:border-lime-900/60 text-xs text-lime-900 dark:text-lime-300 flex items-start justify-between flex-wrap gap-3">
        <div className="flex items-start gap-2.5">
          <Lock className="w-4 h-4 text-lime-600 mt-0.5 flex-shrink-0" />
          <div>
            <span className="font-bold block text-lime-950 dark:text-lime-200">
              Zero-Raw-Audio Privacy Architecture
            </span>
            <p className="text-lime-800 dark:text-lime-400 mt-0.5">
              VoiceShield AI strictly adheres to data minimization principles. Analytical metadata, synthetic probabilities, and risk logs are stored locally. Raw voice recordings and biometric voice prints are never retained on disk or sent to persistent cloud databases.
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={exportMetadataJson}
            disabled={sessions.length === 0}
            className="px-3 py-1.5 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 font-medium hover:bg-slate-50 dark:hover:bg-slate-700 transition flex items-center gap-1.5 disabled:opacity-50"
          >
            <Download className="w-3.5 h-3.5" /> Export JSON
          </button>
          <button
            onClick={onClearHistory}
            disabled={sessions.length === 0}
            className="px-3 py-1.5 rounded-lg bg-red-50 dark:bg-red-950 text-red-600 dark:text-red-400 border border-red-200 dark:border-red-900 font-medium hover:bg-red-100 dark:hover:bg-red-900 transition flex items-center gap-1.5 disabled:opacity-50"
          >
            <Trash2 className="w-3.5 h-3.5" /> Clear
          </button>
        </div>
      </div>

      {/* Main Table Card */}
      <div className="p-5 sm:p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
        {/* Filter Controls */}
        <div className="flex items-center justify-between flex-wrap gap-3 pb-3 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-2">
            <HistoryIcon className="w-5 h-5 text-lime-600" />
            <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
              Analyzed Session Records ({filteredSessions.length})
            </h3>
          </div>

          <div className="flex items-center gap-1.5 text-xs">
            <Filter className="w-3.5 h-3.5 text-slate-400" />
            <span className="text-slate-500 mr-1">Filter by Risk:</span>
            {(['ALL', 'LOW', 'MEDIUM', 'HIGH'] as const).map((r) => (
              <button
                key={r}
                onClick={() => setFilterRisk(r)}
                className={`px-2.5 py-1 rounded-md font-semibold transition ${
                  filterRisk === r
                    ? 'bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900'
                    : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
              >
                {r}
              </button>
            ))}
          </div>
        </div>

        {/* Sessions Table */}
        {filteredSessions.length === 0 ? (
          <div className="py-16 text-center text-slate-400 text-xs">
            No session records matching the current filter.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs font-mono">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-500 text-[11px]">
                  <th className="py-2 px-3">Timestamp</th>
                  <th className="py-2 px-3">Session Title</th>
                  <th className="py-2 px-3">Input Type</th>
                  <th className="py-2 px-3">Synthetic Prob</th>
                  <th className="py-2 px-3">Risk Level</th>
                  <th className="py-2 px-3">Confidence</th>
                  <th className="py-2 px-3">Status</th>
                  <th className="py-2 px-3 text-right">Details</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800/70">
                {filteredSessions.map((session) => (
                  <tr key={session.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40 transition">
                    <td className="py-3 px-3 text-slate-500">
                      {new Date(session.timestamp).toLocaleDateString()} {new Date(session.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </td>
                    <td className="py-3 px-3 font-semibold text-slate-800 dark:text-slate-200 font-sans">
                      {session.title}
                    </td>
                    <td className="py-3 px-3 text-slate-600 dark:text-slate-400">
                      {session.inputType}
                    </td>
                    <td className="py-3 px-3">
                      <span className={`font-bold ${
                        session.syntheticProbability > 65 ? 'text-red-500' :
                        session.syntheticProbability > 35 ? 'text-amber-500' : 'text-lime-600'
                      }`}>
                        {session.syntheticProbability}%
                      </span>
                    </td>
                    <td className="py-3 px-3">
                      <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                        session.riskLevel === 'HIGH' ? 'bg-red-100 text-red-700 dark:bg-red-950 dark:text-red-300' :
                        session.riskLevel === 'MEDIUM' ? 'bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-300' :
                        'bg-lime-100 text-lime-700 dark:bg-lime-950 dark:text-lime-300'
                      }`}>
                        {session.riskLevel}
                      </span>
                    </td>
                    <td className="py-3 px-3 text-slate-600 dark:text-slate-400">
                      {session.confidence}%
                    </td>
                    <td className="py-3 px-3">
                      <span className="text-slate-700 dark:text-slate-300 text-[11px]">
                        {session.status}
                      </span>
                    </td>
                    <td className="py-3 px-3 text-right">
                      <button
                        onClick={() => setSelectedSession(session)}
                        className="p-1.5 rounded-lg text-slate-500 hover:text-lime-600 dark:hover:text-lime-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
                        title="View Session Details"
                      >
                        <Eye className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Session Details Modal / Drawer */}
      {selectedSession && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs animate-in fade-in duration-150">
          <div className="relative w-full max-w-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-2xl p-6 space-y-4 max-h-[85vh] overflow-y-auto text-slate-900 dark:text-slate-100">
            <div className="flex items-start justify-between gap-3 pb-3 border-b border-slate-200 dark:border-slate-800">
              <div>
                <span className="text-[10px] font-mono uppercase text-slate-400">Analysis Session Detail</span>
                <h3 className="text-lg font-bold text-slate-900 dark:text-slate-100 font-sans">
                  {selectedSession.title}
                </h3>
                <span className="text-xs font-mono text-slate-500">
                  {new Date(selectedSession.timestamp).toLocaleString()} • {selectedSession.inputType}
                </span>
              </div>
              <button
                onClick={() => setSelectedSession(null)}
                className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Metrics Grid */}
            <div className="grid grid-cols-3 gap-2.5 text-center font-mono text-xs">
              <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800">
                <span className="text-[11px] text-slate-500 block">Synthetic Prob</span>
                <span className="text-base font-bold text-slate-900 dark:text-slate-100">
                  {selectedSession.syntheticProbability}%
                </span>
              </div>
              <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800">
                <span className="text-[11px] text-slate-500 block">Risk Level</span>
                <span className="text-base font-bold text-slate-900 dark:text-slate-100">
                  {selectedSession.riskLevel}
                </span>
              </div>
              <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800">
                <span className="text-[11px] text-slate-500 block">Certainty</span>
                <span className="text-base font-bold text-slate-900 dark:text-slate-100">
                  {selectedSession.confidence}%
                </span>
              </div>
            </div>

            {/* Recommendation Box */}
            <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-800 text-xs">
              <span className="font-bold text-slate-800 dark:text-slate-200 block mb-1">
                Risk Engine Evaluation:
              </span>
              <p className="text-slate-600 dark:text-slate-300 leading-relaxed">
                {selectedSession.recommendation}
              </p>
            </div>

            {/* Privacy Assurance */}
            <div className="p-3 rounded-xl bg-lime-50 dark:bg-lime-950/40 border border-lime-200 dark:border-lime-800 text-[11px] text-lime-800 dark:text-lime-300 flex items-center gap-2">
              <Lock className="w-4 h-4 text-lime-600 flex-shrink-0" />
              <span>VoiceShield Privacy: No raw audio file was stored for this session. Only spectral vectors & risk scores were logged.</span>
            </div>

            <div className="pt-2 text-right">
              <button
                onClick={() => setSelectedSession(null)}
                className="px-4 py-2 rounded-xl text-xs font-semibold bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 transition"
              >
                Close Details
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
