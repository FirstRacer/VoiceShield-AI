import React from 'react';
import {
  Code,
  Server,
  Cpu,
  Radio,
  Database,
  Cloud,
  CheckCircle2,
  AlertCircle,
  Lock,
} from 'lucide-react';

export const TechStackView: React.FC = () => {
  const stackCategories = [
    {
      title: 'Frontend Architecture',
      subtitle: 'Real-Time Web Audio Interface & Reactive UI',
      icon: Code,
      badge: 'Client Engine',
      technologies: [
        { name: 'React 19', role: 'Component-driven reactive user interface' },
        { name: 'TypeScript', role: 'Type-safe contracts for acoustic chunks & risk structures' },
        { name: 'Vite', role: 'High-performance ES module bundler & dev server' },
        { name: 'Tailwind CSS', role: 'Utility styling with 3 distinct contrast themes' },
        { name: 'Web Audio API', role: 'AudioContext, 16 kHz WAV encoding & oscilloscope visualizer' },
      ],
    },
    {
      title: 'Backend API & Inference Gateway',
      subtitle: 'Streaming Speech Processing Pipeline',
      icon: Server,
      badge: 'Inference Gateway',
      technologies: [
        { name: 'Express / Node.js', role: 'Server-side API proxy with multipart audio chunk ingestion' },
        { name: 'FastAPI / Python Service', role: 'Low-latency ASGI endpoints for neural model inference' },
        { name: 'W2V2-AASIST Model', role: 'SpeechAntiSpoofingBenchmarks / W2V2-AASIST 2-class classifier' },
        { name: 'Gemini AI Advisory', role: 'Generates security advice & explanation strictly after genuine model classification' },
      ],
    },
    {
      title: 'Deepfake Speech Models',
      subtitle: 'Neural Acoustic Authenticity Pipeline',
      icon: Cpu,
      badge: 'Model Architecture',
      technologies: [
        { name: 'PyTorch', role: 'Deep learning tensor processing runtime' },
        { name: 'AASIST & RawNet2', role: 'Graph attention network specialized in anti-spoofing' },
        { name: 'wav2vec 2.0 Embeddings', role: 'Self-supervised acoustic representation extraction' },
        { name: 'Vocoder Artifact Filters', role: 'High-frequency phase discontinuity detectors' },
      ],
    },
    {
      title: 'Audio Preprocessing & DSP',
      subtitle: 'Digital Signal Processing Engine',
      icon: Radio,
      badge: 'DSP Stack',
      technologies: [
        { name: '16 kHz Mono Resampler', role: 'Downsampling and channel reduction matching model input tensor specs' },
        { name: 'WAV Encoder', role: 'Linear 16-bit PCM WAV chunk packaging' },
        { name: 'VAD (Voice Activity Detection)', role: 'Energy-based speech segmentation filtering pure silence' },
      ],
    },
    {
      title: 'Telephony & Network Integration',
      subtitle: 'Architecture for Carrier-Level Voice Inspection',
      icon: Database,
      badge: 'Architecture',
      technologies: [
        { name: 'SIP / VoIP Gateway API', role: 'Telecom carrier network tap for cellular interception' },
        { name: 'Local Structured Storage', role: 'Session metadata & risk audit logs without storing raw voice' },
      ],
    },
    {
      title: 'Cloud & Security Infrastructure',
      subtitle: 'Scalable Containerized Environment',
      icon: Cloud,
      badge: 'Cloud Defense',
      technologies: [
        { name: 'Docker / Cloud Run', role: 'Containerized deployment with auto-scaling to zero' },
        { name: 'HTTPS & TLS 1.3', role: 'Mandatory cryptographic channel for audio streams' },
      ],
    },
  ];

  return (
    <div className="space-y-8 animate-in fade-in duration-200">
      {/* Top Banner */}
      <div className="p-6 sm:p-8 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
        <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-md text-[10px] font-bold uppercase tracking-wider bg-lime-100 dark:bg-lime-950 text-lime-800 dark:text-lime-300 border border-lime-300 dark:border-lime-800 mb-2">
          VOICE SHIELD AI • ARCHITECTURE
        </div>
        <h2 className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-slate-50 tracking-tight">
          System Architecture & Technology Stack
        </h2>
        <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 mt-2 max-w-3xl leading-relaxed">
          VoiceShield AI employs a multi-tiered architecture decoupling client-side acoustic signal capture, sliding-window chunk evaluation, neural speech spoofing inference, and real-time user safety guidance.
        </p>
      </div>

      {/* Distinction Banner: Working Client vs Future Telecom Integration */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Working Application */}
        <div className="p-5 rounded-2xl bg-lime-50/70 dark:bg-lime-950/30 border border-lime-200 dark:border-lime-800/60 space-y-2">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-lime-600" />
            <h3 className="text-sm font-bold text-lime-950 dark:text-lime-200">
              VoiceShield AI Application Pipeline
            </h3>
          </div>
          <p className="text-xs text-lime-800 dark:text-lime-400 leading-relaxed">
            Direct real-time capture from <strong>microphone hardware</strong> and <strong>uploaded audio recordings</strong>. Complete client-side sliding chunk pipeline, Web Audio API oscilloscope, dynamic risk aggregation engine, and proactive high-risk safety alerts.
          </p>
        </div>

        {/* Future Integration */}
        <div className="p-5 rounded-2xl bg-blue-50/70 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-800/60 space-y-2">
          <div className="flex items-center gap-2">
            <AlertCircle className="w-5 h-5 text-blue-600" />
            <h3 className="text-sm font-bold text-blue-950 dark:text-blue-200">
              Carrier & Telecom Gateway API Specification
            </h3>
          </div>
          <p className="text-xs text-blue-800 dark:text-blue-400 leading-relaxed">
            Standard web browsers cannot directly intercept 4G/5G cellular voice calls due to mobile OS sandboxing. Telecom integration is architected as an <strong>IMS / SIP Telephony Carrier Gateway API</strong>, analyzing VoIP and cellular streams before handing off to end devices.
          </p>
        </div>
      </div>

      {/* Tech Stack Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {stackCategories.map((category) => {
          const Icon = category.icon;
          return (
            <div
              key={category.title}
              className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <div className="p-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                    <Icon className="w-5 h-5 text-lime-600 dark:text-lime-400" />
                  </div>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 font-semibold border border-slate-200 dark:border-slate-700">
                    {category.badge}
                  </span>
                </div>

                <h4 className="text-sm font-bold text-slate-900 dark:text-slate-100">
                  {category.title}
                </h4>
                <p className="text-xs text-slate-500 dark:text-slate-400 mb-4">
                  {category.subtitle}
                </p>

                <div className="space-y-2.5 pt-2 border-t border-slate-100 dark:border-slate-800">
                  {category.technologies.map((tech) => (
                    <div key={tech.name} className="text-xs">
                      <span className="font-bold font-mono text-slate-900 dark:text-slate-200 block">
                        {tech.name}
                      </span>
                      <span className="text-[11px] text-slate-500 dark:text-slate-400">
                        {tech.role}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Security Principles Summary */}
      <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-3">
        <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
          <Lock className="w-4 h-4 text-lime-600" />
          <span>Security & Engineering Compliance</span>
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs text-slate-600 dark:text-slate-400">
          <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50">
            <strong>Server-Side API Protection:</strong> Inference credentials and backend endpoints remain strictly protected.
          </div>
          <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50">
            <strong>Data Minimization:</strong> Raw voice recordings are quarantined in transient RAM buffers and purged immediately post-inference.
          </div>
          <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50">
            <strong>No Faked Numbers:</strong> Risk calculations stem purely from real model evaluations.
          </div>
          <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50">
            <strong>Advisory Barrier:</strong> Emergency calls and banking operations are never automatically blocked without user awareness.
          </div>
        </div>
      </div>
    </div>
  );
};
