import React from 'react';
import { ActiveTab, AnalysisSession, CurrentDetectionState } from '../types';
import {
  ShieldCheck,
  ShieldAlert,
  AlertTriangle,
  Activity,
  Mic,
  FileAudio,
  Clock,
  ArrowRight,
  Lock,
  Layers,
} from 'lucide-react';

interface DashboardViewProps {
  sessions: AnalysisSession[];
  setActiveTab: (tab: ActiveTab) => void;
  isProtectionActive: boolean;
  modelStatus?: 'ONLINE' | 'OFFLINE' | 'CHECKING';
  currentDetection?: CurrentDetectionState | null;
  onOpenSettings?: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  sessions,
  setActiveTab,
  isProtectionActive,
  modelStatus = 'CHECKING',
  currentDetection = null,
  onOpenSettings,
}) => {
  const isModelOnline = modelStatus !== 'OFFLINE';

  // Aggregate statistics - only active when real model is online
  const totalSessions = isModelOnline ? sessions.length : 0;
  const highRiskCount = isModelOnline ? sessions.filter((s) => s.riskLevel === 'HIGH').length : 0;
  const mediumRiskCount = isModelOnline ? sessions.filter((s) => s.riskLevel === 'MEDIUM').length : 0;
  const lowRiskCount = isModelOnline ? sessions.filter((s) => s.riskLevel === 'LOW').length : 0;

  const lowPercent = totalSessions > 0 ? Math.round((lowRiskCount / totalSessions) * 100) : 0;
  const medPercent = totalSessions > 0 ? Math.round((mediumRiskCount / totalSessions) * 100) : 0;
  const highPercent = totalSessions > 0 ? Math.round((highRiskCount / totalSessions) * 100) : 0;

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Top Status Hero */}
      <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs flex items-center justify-between flex-wrap gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-[10px] font-mono px-2 py-0.5 rounded-md font-bold uppercase tracking-wider bg-lime-100 dark:bg-lime-950/70 text-lime-800 dark:text-lime-300 border border-lime-300 dark:border-lime-800">
              VOICE SHIELD AI
            </span>
            <span className="text-xs text-slate-500 font-mono tracking-wider">
              LISTEN • DETECT • PROTECT
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-slate-50 tracking-tight">
            VoiceShield AI Security Operations
          </h1>
          <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 mt-1 max-w-2xl">
            Continuous real-time voice analysis protecting against deepfake impersonation, CEO fraud, and unauthorized voice-based attacks.
          </p>
        </div>

        {/* Real Model Backend Status Badge */}
        <div className="flex items-center gap-3">
          {isModelOnline ? (
            <div className="p-4 rounded-xl bg-lime-50 dark:bg-lime-950/40 border border-lime-200 dark:border-lime-800 flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-lime-600 text-white flex items-center justify-center">
                <ShieldCheck className="w-6 h-6" />
              </div>
              <div>
                <span className="text-[11px] font-mono text-lime-800 dark:text-lime-300 block font-semibold">
                  REAL NEURAL MODEL
                </span>
                <span className="text-sm font-bold text-slate-900 dark:text-slate-100">
                  W2V2-AASIST: ONLINE
                </span>
              </div>
            </div>
          ) : (
            <div
              onClick={onOpenSettings}
              className="p-4 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 flex items-center gap-3 cursor-pointer hover:bg-amber-100/70 transition"
              title="Click to configure FastAPI service URL"
            >
              <div className="w-10 h-10 rounded-lg bg-amber-600 text-white flex items-center justify-center">
                <AlertTriangle className="w-6 h-6" />
              </div>
              <div>
                <span className="text-[11px] font-mono text-amber-800 dark:text-amber-300 block font-semibold">
                  REAL NEURAL MODEL
                </span>
                <span className="text-sm font-bold text-slate-900 dark:text-slate-100">
                  OFFLINE (Click to Setup)
                </span>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Prominent Real Model Offline Warning Banner */}
      {!isModelOnline && (
        <div className="p-4 rounded-2xl bg-amber-50/90 dark:bg-amber-950/40 border border-amber-300 dark:border-amber-800 text-amber-900 dark:text-amber-200 flex items-start justify-between flex-wrap gap-3 animate-in fade-in">
          <div className="flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-amber-600 dark:text-amber-400 mt-0.5 flex-shrink-0" />
            <div>
              <h2 className="text-sm font-black uppercase tracking-wider text-amber-900 dark:text-amber-100">
                REAL MODEL OFFLINE
              </h2>
              <p className="text-xs text-amber-800 dark:text-amber-300 mt-0.5">
                Detection unavailable — connect the W2V2-AASIST backend to analyze audio.
              </p>
            </div>
          </div>
          {onOpenSettings && (
            <button
              onClick={onOpenSettings}
              className="px-3 py-1.5 rounded-lg text-xs font-bold bg-amber-600 hover:bg-amber-700 text-white shadow-xs cursor-pointer transition"
            >
              Connect Backend
            </button>
          )}
        </div>
      )}

      {/* Key Metrics Bar */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Metric 1: Current Threat Posture */}
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider">Current Threat Posture</span>
            <Activity className={`w-4 h-4 ${isModelOnline && currentDetection?.status === 'READY' ? 'text-lime-600' : 'text-slate-400'}`} />
          </div>

          {!isModelOnline ? (
            <div className="space-y-1">
              <div className="text-xl sm:text-2xl font-black font-mono text-amber-600 dark:text-amber-400">
                NO RESULT
              </div>
              <div className="text-xs font-bold uppercase tracking-wider text-amber-700 dark:text-amber-300">
                REAL MODEL OFFLINE
              </div>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-snug">
                Detection unavailable — connect the W2V2-AASIST backend to analyze audio.
              </p>
            </div>
          ) : currentDetection?.status === 'READY' && currentDetection.probability !== null && currentDetection.riskLevel ? (
            <div className="space-y-1">
              <div className={`text-2xl font-black font-mono ${
                currentDetection.riskLevel === 'HIGH'
                  ? 'text-red-600 dark:text-red-400'
                  : currentDetection.riskLevel === 'MEDIUM'
                  ? 'text-amber-600 dark:text-amber-400'
                  : 'text-lime-600 dark:text-lime-400'
              }`}>
                {currentDetection.riskLevel}
              </div>
              <span className="text-[11px] text-slate-500 mt-1 block font-mono">
                Model probability: {currentDetection.probability}%
              </span>
              {currentDetection.confidence !== null && (
                <span className="text-[10px] text-slate-400 font-mono block">
                  Confidence: {currentDetection.confidence}%
                </span>
              )}
            </div>
          ) : (
            <div className="space-y-1">
              <div className="text-xl sm:text-2xl font-bold font-mono text-slate-600 dark:text-slate-400">
                WAITING
              </div>
              <span className="text-[11px] text-slate-500 mt-1 block">
                Waiting for real model...
              </span>
            </div>
          )}
        </div>

        {/* Metric 2: High-Risk Clones Flagged */}
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider">High-Risk Clones Flagged</span>
            <ShieldAlert className="w-4 h-4 text-red-500" />
          </div>
          <div className="text-2xl font-black font-mono text-red-600 dark:text-red-400">
            {!isModelOnline ? '—' : highRiskCount}
          </div>
          <span className="text-[11px] text-slate-500 mt-1 block">
            {!isModelOnline ? 'Detection unavailable' : 'Independent caution recommended'}
          </span>
        </div>

        {/* Metric 3: Evaluated Sessions */}
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider">Evaluated Sessions</span>
            <Clock className="w-4 h-4 text-slate-500" />
          </div>
          <div className="text-2xl font-black font-mono text-slate-900 dark:text-slate-50">
            {!isModelOnline ? '—' : totalSessions}
          </div>
          <span className="text-[11px] text-slate-500 mt-1 block">
            {!isModelOnline ? 'Model offline' : 'Across live streams & file uploads'}
          </span>
        </div>

        {/* Metric 4: Detection Architecture */}
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider">Detection Architecture</span>
            <Lock className="w-4 h-4 text-lime-600" />
          </div>
          <div className="text-xs font-bold text-slate-900 dark:text-slate-100 uppercase tracking-tight">
            W2V2-AASIST Neural Pipeline
          </div>
          <span className="text-[11px] text-slate-500 mt-1 block">
            Zero synthetic simulation data
          </span>
        </div>
      </div>

      {/* Quick Launch Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Launch Live Protection */}
        <div
          onClick={() => setActiveTab('live')}
          className="group p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-lime-500 dark:hover:border-lime-500/80 shadow-xs hover:shadow-md transition cursor-pointer"
        >
          <div className="flex items-center justify-between mb-3">
            <div className="p-3 rounded-xl bg-lime-100 dark:bg-lime-950/80 text-lime-700 dark:text-lime-400 group-hover:scale-105 transition-transform">
              <Mic className="w-6 h-6" />
            </div>
            <div className="flex items-center gap-2">
              {!isModelOnline && (
                <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-amber-100 dark:bg-amber-950/80 text-amber-800 dark:text-amber-300 border border-amber-300 dark:border-amber-800">
                  Backend Offline
                </span>
              )}
              <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-lime-500 transition-colors" />
            </div>
          </div>
          <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">
            Live Voice Protection
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Capture live microphone audio in real-time, view live oscilloscope waveforms, and evaluate rolling synthetic probability.
          </p>
        </div>

        {/* Launch Audio File Test */}
        <div
          onClick={() => setActiveTab('audio-test')}
          className="group p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-lime-500 dark:hover:border-lime-500/80 shadow-xs hover:shadow-md transition cursor-pointer"
        >
          <div className="flex items-center justify-between mb-3">
            <div className="p-3 rounded-xl bg-blue-100 dark:bg-blue-950/80 text-blue-700 dark:text-blue-400 group-hover:scale-105 transition-transform">
              <FileAudio className="w-6 h-6" />
            </div>
            <div className="flex items-center gap-2">
              {!isModelOnline && (
                <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-amber-100 dark:bg-amber-950/80 text-amber-800 dark:text-amber-300 border border-amber-300 dark:border-amber-800">
                  Backend Offline
                </span>
              )}
              <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-blue-500 transition-colors" />
            </div>
          </div>
          <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">
            Audio File Analysis
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Upload WAV/MP3 recordings or test reference speech attack samples for neural vocoder artifact detection.
          </p>
        </div>

        {/* Technical Architecture */}
        <div
          onClick={() => setActiveTab('tech-stack')}
          className="group p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-lime-500 dark:hover:border-lime-500/80 shadow-xs hover:shadow-md transition cursor-pointer"
        >
          <div className="flex items-center justify-between mb-3">
            <div className="p-3 rounded-xl bg-purple-100 dark:bg-purple-950/80 text-purple-700 dark:text-purple-400 group-hover:scale-105 transition-transform">
              <Layers className="w-6 h-6" />
            </div>
            <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-purple-500 transition-colors" />
          </div>
          <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">
            Speech Anti-Spoofing Architecture
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Explore the W2V2-AASIST neural graph attention network, logit transformation, and privacy safeguards.
          </p>
        </div>
      </div>

      {/* Two-Column Lower Grid: Risk Distribution & Recent Events */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Risk Distribution Chart (5 Cols) */}
        <div className="lg:col-span-5 p-5 sm:p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
              Risk Level Distribution
            </h3>
            <span className="text-xs font-mono text-slate-400">All Evaluated Chunks</span>
          </div>

          {!isModelOnline ? (
            <div className="py-8 px-4 rounded-xl bg-amber-50/50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-900/50 text-center space-y-1.5">
              <AlertTriangle className="w-6 h-6 mx-auto text-amber-500" />
              <div className="text-xs font-bold uppercase tracking-wider text-amber-900 dark:text-amber-200">
                REAL MODEL OFFLINE
              </div>
              <div className="text-[11px] text-slate-500 dark:text-slate-400">
                Detection unavailable — connect the W2V2-AASIST backend to analyze audio.
              </div>
            </div>
          ) : totalSessions === 0 ? (
            <div className="py-8 text-center text-slate-400 text-xs">
              No sessions analyzed yet. Waiting for real model inference...
            </div>
          ) : (
            /* Bar Chart Representation */
            <div className="space-y-3 pt-2">
              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-lime-600 dark:text-lime-400 font-semibold">Low Risk (&lt;35%)</span>
                  <span className="font-mono text-slate-700 dark:text-slate-300 font-bold">{lowRiskCount} ({lowPercent}%)</span>
                </div>
                <div className="h-2.5 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                  <div className="h-full bg-lime-500 rounded-full" style={{ width: `${lowPercent}%` }} />
                </div>
              </div>

              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-amber-600 dark:text-amber-400 font-semibold">Medium Risk (35-65%)</span>
                  <span className="font-mono text-slate-700 dark:text-slate-300 font-bold">{mediumRiskCount} ({medPercent}%)</span>
                </div>
                <div className="h-2.5 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                  <div className="h-full bg-amber-500 rounded-full" style={{ width: `${medPercent}%` }} />
                </div>
              </div>

              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-red-600 dark:text-red-400 font-semibold">High Risk (&gt;65%)</span>
                  <span className="font-mono text-slate-700 dark:text-slate-300 font-bold">{highRiskCount} ({highPercent}%)</span>
                </div>
                <div className="h-2.5 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                  <div className="h-full bg-red-600 rounded-full" style={{ width: `${highPercent}%` }} />
                </div>
              </div>
            </div>
          )}

          <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-950/50 border border-slate-200 dark:border-slate-800 text-xs text-slate-600 dark:text-slate-400">
            <strong>Dynamic Aggregation Logic:</strong> Multiple successive speech chunks are analyzed with robust trimmed aggregation to calculate the final overall voice risk score.
          </div>
        </div>

        {/* Recent Detection Events (7 Cols) */}
        <div className="lg:col-span-7 p-5 sm:p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
              Recent Detection & Threat Assessment Events
            </h3>
            <button
              onClick={() => setActiveTab('history')}
              className="text-xs font-semibold text-lime-600 hover:text-lime-700 dark:text-lime-400 inline-flex items-center gap-1 cursor-pointer"
            >
              View Full History <ArrowRight className="w-3 h-3" />
            </button>
          </div>

          {!isModelOnline ? (
            <div className="py-12 px-4 rounded-xl bg-amber-50/50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-900/50 text-center space-y-1.5">
              <AlertTriangle className="w-6 h-6 mx-auto text-amber-500" />
              <div className="text-xs font-bold uppercase tracking-wider text-amber-900 dark:text-amber-200">
                REAL MODEL OFFLINE
              </div>
              <div className="text-xs text-slate-500 dark:text-slate-400">
                Detection unavailable — connect the W2V2-AASIST backend to analyze audio.
              </div>
            </div>
          ) : sessions.length === 0 ? (
            <div className="py-12 text-center text-slate-400 text-xs">
              No sessions analyzed yet. Start live voice protection or run an audio test.
            </div>
          ) : (
            <div className="divide-y divide-slate-100 dark:divide-slate-800/80">
              {sessions.slice(0, 4).map((item) => (
                <div key={item.id} className="py-3 flex items-center justify-between gap-3 text-xs">
                  <div className="flex items-center gap-3">
                    <div className={`p-2 rounded-lg ${
                      item.riskLevel === 'HIGH' ? 'bg-red-100 text-red-600 dark:bg-red-950' :
                      item.riskLevel === 'MEDIUM' ? 'bg-amber-100 text-amber-600 dark:bg-amber-950' :
                      'bg-lime-100 text-lime-600 dark:bg-lime-950'
                    }`}>
                      {item.riskLevel === 'HIGH' ? <ShieldAlert className="w-4 h-4" /> :
                       item.riskLevel === 'MEDIUM' ? <AlertTriangle className="w-4 h-4" /> :
                       <ShieldCheck className="w-4 h-4" />}
                    </div>
                    <div>
                      <span className="font-bold text-slate-900 dark:text-slate-100 block">
                        {item.title}
                      </span>
                      <span className="text-[11px] text-slate-500 font-mono">
                        {new Date(item.timestamp).toLocaleTimeString()} • {item.inputType}
                      </span>
                    </div>
                  </div>

                  <div className="text-right">
                    <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                      item.riskLevel === 'HIGH' ? 'bg-red-100 text-red-700 dark:bg-red-950 dark:text-red-300' :
                      item.riskLevel === 'MEDIUM' ? 'bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-300' :
                      'bg-lime-100 text-lime-700 dark:bg-lime-950 dark:text-lime-300'
                    }`}>
                      {item.riskLevel} ({item.syntheticProbability}%)
                    </span>
                    <span className="block text-[11px] text-slate-400 font-mono mt-0.5">
                      {item.status}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
