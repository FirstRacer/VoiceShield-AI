import React, { useState, useRef, useEffect } from 'react';
import {
  RiskLevel,
  AudioChunkResult,
  DetectionSettings,
  AnalysisSession,
} from '../types';
import { SAMPLE_AUDIO_CLIPS, SampleAudioClip } from '../data/sampleAudioClips';
import { AudioAnalysisService } from '../services/audioAnalyzer';
import { soundSynth } from '../services/soundGenerator';
import { RiskMeter } from '../components/RiskMeter';
import { HighRiskAlertModal } from '../components/HighRiskAlertModal';
import {
  Upload,
  FileAudio,
  Play,
  Square,
  AlertCircle,
  CheckCircle2,
  AlertTriangle,
  ShieldAlert,
  Loader2,
  Sparkles,
  Info,
  Volume2,
} from 'lucide-react';

interface AudioTestViewProps {
  settings: DetectionSettings;
  onSessionComplete?: (session: AnalysisSession) => void;
  onOpenSettings?: () => void;
  modelStatus?: 'ONLINE' | 'OFFLINE' | 'CHECKING';
}

export const AudioTestView: React.FC<AudioTestViewProps> = ({
  settings,
  onSessionComplete,
  onOpenSettings,
  modelStatus = 'CHECKING',
}) => {
  const isModelOnline = modelStatus !== 'OFFLINE';
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [selectedSample, setSelectedSample] = useState<SampleAudioClip | null>(
    () => SAMPLE_AUDIO_CLIPS[0] || null
  );

  const [isProcessing, setIsProcessing] = useState(false);
  const [processingStage, setProcessingStage] = useState('');
  const [processingPercent, setProcessingPercent] = useState(0);
  const [serviceError, setServiceError] = useState<string | null>(null);

  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const audioStopRef = useRef<(() => void) | null>(null);

  // Analysis Results State
  const [analysisResult, setAnalysisResult] = useState<{
    probability: number;
    rollingAvg: number;
    riskLevel: RiskLevel;
    confidence: number;
    chunks: AudioChunkResult[];
    explanation: string;
    recommendation: string;
  } | null>(null);

  // Clear stale analysis results if model is offline
  useEffect(() => {
    if (!isModelOnline) {
      setAnalysisResult(null);
    }
  }, [isModelOnline]);

  // High-Risk Safety Warning Modal
  const [showAlertModal, setShowAlertModal] = useState(false);

  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Handle Drag and Drop
  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const file = e.dataTransfer.files[0];
      setSelectedFile(file);
      setSelectedSample(null);
      setAnalysisResult(null);
      setServiceError(null);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setSelectedFile(e.target.files[0]);
      setSelectedSample(null);
      setAnalysisResult(null);
      setServiceError(null);
    }
  };

  const handleSelectSample = (sample: SampleAudioClip) => {
    setSelectedSample(sample);
    setSelectedFile(null);
    setAnalysisResult(null);
    setServiceError(null);
    if (isPlayingAudio && audioStopRef.current) {
      audioStopRef.current();
      setIsPlayingAudio(false);
    }
  };

  const togglePlayAudio = () => {
    if (isPlayingAudio) {
      if (audioStopRef.current) {
        audioStopRef.current();
      }
      setIsPlayingAudio(false);
    } else {
      const synthType = selectedSample ? selectedSample.synthesizerType : 'human';
      const handle = soundSynth.playAcousticSimulation(synthType, 4);
      audioStopRef.current = handle.stop;
      setIsPlayingAudio(true);
      setTimeout(() => {
        setIsPlayingAudio(false);
      }, 4000);
    }
  };

  const handleAnalyze = async () => {
    if (!isModelOnline) {
      setServiceError('Detection unavailable — connect the W2V2-AASIST backend to analyze audio.');
      return;
    }

    setIsProcessing(true);
    setProcessingPercent(0);
    setServiceError(null);

    const analyzer = new AudioAnalysisService(settings);

    try {
      let targetFile: File;

      if (selectedFile) {
        targetFile = selectedFile;
      } else if (selectedSample) {
        setProcessingStage('Synthesizing 16 kHz WAV audio sample...');
        setProcessingPercent(10);
        targetFile = await soundSynth.generateWavFile(
          selectedSample.synthesizerType,
          selectedSample.name,
          4.0
        );
      } else {
        setIsProcessing(false);
        return;
      }

      const res = await analyzer.analyzeAudioFile(targetFile, (stage, percent) => {
        setProcessingStage(stage);
        setProcessingPercent(percent);
      });

      setAnalysisResult({
        probability: res.probability,
        rollingAvg: res.rollingAvg,
        riskLevel: res.riskLevel,
        confidence: res.confidence,
        chunks: res.chunks,
        explanation: res.explanation,
        recommendation: res.recommendation,
      });

      if (res.riskLevel === 'HIGH') {
        setShowAlertModal(true);
      }

      if (onSessionComplete) {
        onSessionComplete({
          id: `file-${Date.now()}`,
          title: `File: ${targetFile.name}`,
          timestamp: Date.now(),
          inputType: 'Audio Upload',
          durationSeconds: Math.max(1, Math.round(res.chunks.length * 1.5)),
          syntheticProbability: res.probability,
          rollingAverage: res.rollingAvg,
          riskLevel: res.riskLevel,
          confidence: res.confidence,
          status: res.riskLevel === 'HIGH' ? 'Alert Triggered' : 'Normal',
          recommendation: res.recommendation,
          chunks: res.chunks,
          fileName: targetFile.name,
        });
      }
    } catch (err: unknown) {
      const errorMsg = err instanceof Error ? err.message : 'Error decoding or analyzing audio file.';
      setServiceError(errorMsg);
      setProcessingStage('Analysis failed.');
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Prominent Offline Banner if backend offline */}
      {!isModelOnline && (
        <div className="p-4 rounded-2xl bg-amber-50/90 dark:bg-amber-950/40 border border-amber-300 dark:border-amber-800 text-amber-900 dark:text-amber-200 flex items-start justify-between flex-wrap gap-3">
          <div className="flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-amber-600 dark:text-amber-400 mt-0.5 flex-shrink-0" />
            <div>
              <h3 className="text-sm font-black uppercase tracking-wider text-amber-900 dark:text-amber-100">
                REAL MODEL OFFLINE
              </h3>
              <p className="text-xs text-amber-800 dark:text-amber-300 mt-0.5">
                Detection unavailable — connect the W2V2-AASIST backend to analyze audio.
              </p>
            </div>
          </div>
          {onOpenSettings && (
            <button
              onClick={onOpenSettings}
              className="px-3 py-1.5 rounded-lg text-xs font-bold bg-amber-600 hover:bg-amber-700 text-white shadow-xs cursor-pointer transition"
            >
              Configure Backend
            </button>
          )}
        </div>
      )}

      {/* Top Banner */}
      <div className="flex items-center justify-between flex-wrap gap-3 pb-2 border-b border-slate-200 dark:border-slate-800">
        <div>
          <h2 className="text-xl sm:text-2xl font-black tracking-tight text-slate-900 dark:text-slate-100">
            Audio File Authenticity Analysis
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-0.5">
            Evaluate recorded voice clips (WAV/MP3) for neural vocoder cloning artifacts & deepfake anti-spoofing
          </p>
        </div>
        <div className="flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-lime-50 dark:bg-lime-950/60 text-lime-800 dark:text-lime-300 border border-lime-200 dark:border-lime-900">
          <Sparkles className="w-3.5 h-3.5" />
          <span>Upload or Choose Test Vectors</span>
        </div>
      </div>

      {/* Main Analysis Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Upload Box & Sample Picker (7 Cols) */}
        <div className="lg:col-span-7 space-y-5">
          {/* Drag and Drop Upload Card */}
          <div
            onDragOver={(e) => e.preventDefault()}
            onDrop={handleDrop}
            onClick={() => fileInputRef.current?.click()}
            className={`p-6 sm:p-8 rounded-2xl border-2 border-dashed transition-all text-center cursor-pointer ${
              selectedFile
                ? 'border-lime-500 bg-lime-50/40 dark:bg-lime-950/20'
                : 'border-slate-300 dark:border-slate-700 hover:border-lime-400 bg-white dark:bg-slate-900/60'
            }`}
          >
            <input
              ref={fileInputRef}
              type="file"
              accept="audio/wav,audio/mp3,audio/mpeg,audio/ogg,audio/m4a,audio/*"
              className="hidden"
              onChange={handleFileChange}
            />
            <div className="w-12 h-12 rounded-2xl bg-lime-100 dark:bg-lime-950/80 text-lime-600 dark:text-lime-400 flex items-center justify-center mx-auto mb-3">
              <Upload className="w-6 h-6" />
            </div>
            <h3 className="text-sm sm:text-base font-bold text-slate-900 dark:text-slate-100 mb-1">
              {selectedFile ? selectedFile.name : 'Upload Audio Recording (WAV / MP3)'}
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 max-w-sm mx-auto">
              {selectedFile
                ? `${(selectedFile.size / 1024).toFixed(1)} KB • Ready for model inference`
                : 'Drag & drop an audio file here, or click to browse local files.'}
            </p>
          </div>

          {/* Reference Audio Scenarios */}
          <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300">
                Or Select a Reference Test Vector:
              </span>
              <span className="text-[11px] font-mono text-slate-400">1-Click Test</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {SAMPLE_AUDIO_CLIPS.map((sample) => {
                const isSelected = selectedSample?.id === sample.id;
                return (
                  <button
                    key={sample.id}
                    onClick={() => handleSelectSample(sample)}
                    className={`p-3 rounded-xl text-left border transition ${
                      isSelected
                        ? 'border-lime-500 bg-lime-50/50 dark:bg-lime-950/40'
                        : 'border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 bg-slate-50/60 dark:bg-slate-950/30'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span
                        className={`text-[10px] font-bold px-1.5 py-0.5 rounded uppercase ${
                          sample.expectedRisk === 'HIGH'
                            ? 'bg-red-100 text-red-700 dark:bg-red-950'
                            : sample.expectedRisk === 'MEDIUM'
                            ? 'bg-amber-100 text-amber-700 dark:bg-amber-950'
                            : 'bg-lime-100 text-lime-700 dark:bg-lime-950'
                        }`}
                      >
                        {sample.expectedRisk} Risk Profile
                      </span>
                      <span className="text-[10px] font-mono text-slate-400">{sample.durationText}</span>
                    </div>
                    <div className="text-xs font-bold text-slate-900 dark:text-slate-100 line-clamp-1">
                      {sample.name}
                    </div>
                    <p className="text-[11px] text-slate-500 line-clamp-1 mt-0.5">
                      {sample.description}
                    </p>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Audio Preview & Action Bar */}
          {(selectedFile || selectedSample) && (
            <div className="p-4 rounded-xl bg-slate-100/90 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-800 flex items-center justify-between flex-wrap gap-3">
              <div className="flex items-center gap-3">
                <button
                  onClick={togglePlayAudio}
                  className={`p-3 rounded-xl flex items-center justify-center transition shadow-xs cursor-pointer ${
                    isPlayingAudio
                      ? 'bg-slate-800 text-white'
                      : 'bg-lime-600 hover:bg-lime-700 text-white'
                  }`}
                  title={isPlayingAudio ? 'Stop Preview' : 'Play Acoustic Preview'}
                >
                  {isPlayingAudio ? <Square className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                </button>
                <div>
                  <span className="text-xs font-bold block text-slate-900 dark:text-slate-100">
                    {selectedFile ? selectedFile.name : selectedSample?.name}
                  </span>
                  <span className="text-[11px] text-slate-500 flex items-center gap-1.5">
                    <Volume2 className="w-3 h-3" />
                    {isPlayingAudio ? 'Playing acoustic sample...' : 'Click to preview audio'}
                  </span>
                </div>
              </div>

              <button
                onClick={handleAnalyze}
                disabled={isProcessing || !isModelOnline}
                className={`px-6 py-3 rounded-xl font-bold text-xs text-white shadow-md transition flex items-center gap-2 ${
                  !isModelOnline
                    ? 'bg-slate-300 dark:bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-300 dark:border-slate-700'
                    : 'bg-lime-600 hover:bg-lime-700 cursor-pointer'
                }`}
              >
                {isProcessing ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>Processing Audio...</span>
                  </>
                ) : !isModelOnline ? (
                  <>
                    <AlertTriangle className="w-4 h-4 text-amber-500" />
                    <span>Model Offline — Connect Backend</span>
                  </>
                ) : (
                  <>
                    <FileAudio className="w-4 h-4" />
                    <span>Analyze Audio Now</span>
                  </>
                )}
              </button>
            </div>
          )}

          {/* Processing Progress Indicator */}
          {isProcessing && (
            <div className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-2">
                  <Loader2 className="w-3.5 h-3.5 animate-spin text-lime-600" />
                  {processingStage}
                </span>
                <span className="font-mono font-bold text-slate-800 dark:text-slate-200">
                  {processingPercent}%
                </span>
              </div>
              <div className="w-full bg-slate-200 dark:bg-slate-800 h-2 rounded-full overflow-hidden">
                <div
                  className="bg-lime-600 h-full rounded-full transition-all duration-300"
                  style={{ width: `${processingPercent}%` }}
                />
              </div>
            </div>
          )}

          {/* Service Error Alert */}
          {serviceError && (
            <div className="p-4 rounded-xl bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900 text-xs text-red-700 dark:text-red-300 flex items-start gap-2">
              <AlertTriangle className="w-4 h-4 text-red-500 mt-0.5 flex-shrink-0" />
              <div>
                <span className="font-bold block">Analysis Service Unavailable:</span>
                <span>{serviceError}</span>
              </div>
            </div>
          )}
        </div>

        {/* Right Column: Analysis Results & Prominent Risk Display (5 Cols) */}
        <div className="lg:col-span-5 space-y-5">
          {!isModelOnline ? (
            <RiskMeter
              overallScore={null}
              riskLevel={null}
              confidence={null}
              chunkCount={0}
              validChunkCount={0}
              modelOffline={true}
            />
          ) : analysisResult ? (
            <>
              {/* Prominent Risk Meter */}
              <RiskMeter
                overallScore={analysisResult.probability}
                riskLevel={analysisResult.riskLevel}
                confidence={analysisResult.confidence}
                chunkCount={analysisResult.chunks.length}
                validChunkCount={analysisResult.chunks.length}
                modelOffline={false}
              />

              {/* Result Card with Clear Risk Guidance */}
              <div
                className={`p-5 rounded-2xl border ${
                  analysisResult.riskLevel === 'HIGH'
                    ? 'bg-red-50/80 dark:bg-red-950/30 border-red-300 dark:border-red-900/60'
                    : analysisResult.riskLevel === 'MEDIUM'
                    ? 'bg-amber-50/80 dark:bg-amber-950/30 border-amber-300 dark:border-amber-900/60'
                    : 'bg-lime-50/80 dark:bg-lime-950/30 border-lime-300 dark:border-lime-900/60'
                }`}
              >
                <div className="flex items-start gap-3 mb-3">
                  {analysisResult.riskLevel === 'HIGH' ? (
                    <ShieldAlert className="w-6 h-6 text-red-600 flex-shrink-0" />
                  ) : analysisResult.riskLevel === 'MEDIUM' ? (
                    <AlertTriangle className="w-6 h-6 text-amber-600 flex-shrink-0" />
                  ) : (
                    <CheckCircle2 className="w-6 h-6 text-lime-600 flex-shrink-0" />
                  )}
                  <div>
                    <h4 className="text-sm font-bold text-slate-900 dark:text-slate-100">
                      {analysisResult.riskLevel === 'HIGH'
                        ? 'Potential AI-Generated Voice Detected'
                        : analysisResult.riskLevel === 'MEDIUM'
                        ? 'Ambiguous Acoustic Signatures Detected'
                        : 'No Strong Synthetic Indicators Detected'}
                    </h4>
                    <p className="text-xs text-slate-600 dark:text-slate-300 mt-1 leading-relaxed">
                      {analysisResult.explanation}
                    </p>
                  </div>
                </div>

                {/* Directives for High Risk */}
                {analysisResult.riskLevel === 'HIGH' && (
                  <div className="mt-3 p-3 rounded-xl bg-white/90 dark:bg-slate-900/90 border border-red-200 dark:border-red-800 text-xs text-slate-800 dark:text-slate-200 space-y-1.5">
                    <span className="font-bold text-red-600 block">Critical Directives:</span>
                    <div>• Do not share OTPs, passwords or banking information.</div>
                    <div>• Do not authorize payments or transfers based only on this conversation.</div>
                    <div>• Confirm the request independently before proceeding.</div>
                  </div>
                )}

                {/* Recommendation Box */}
                <div className="mt-3 pt-3 border-t border-slate-200/60 dark:border-slate-800 text-xs">
                  <span className="font-bold text-slate-800 dark:text-slate-200 block mb-1">
                    Defensive Recommendation:
                  </span>
                  <p className="text-slate-600 dark:text-slate-300 leading-relaxed">
                    {analysisResult.recommendation}
                  </p>
                </div>
              </div>

              {/* Privacy Notice */}
              <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-950/40 border border-slate-200 dark:border-slate-800 text-[11px] text-slate-500 flex items-center gap-2">
                <Info className="w-3.5 h-3.5 flex-shrink-0 text-lime-500" />
                <span>Zero raw audio is retained on disk. Memory buffers were cleared after inference.</span>
              </div>
            </>
          ) : (
            <div className="p-8 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-center text-slate-400 space-y-3">
              <FileAudio className="w-10 h-10 mx-auto text-slate-300 dark:text-slate-700" />
              <h4 className="text-sm font-bold text-slate-700 dark:text-slate-300">
                Awaiting Audio Input
              </h4>
              <p className="text-xs max-w-xs mx-auto leading-relaxed">
                Upload a recording or pick one of the reference test clips on the left, then click <strong>Analyze Audio Now</strong> to evaluate the voice risk.
              </p>
            </div>
          )}
        </div>
      </div>

      {/* High-Risk Alert Popup with CONTINUE WITH CAUTION */}
      <HighRiskAlertModal
        isOpen={showAlertModal}
        probability={analysisResult?.probability || 0}
        onContinueWithCaution={() => setShowAlertModal(false)}
        onClose={() => setShowAlertModal(false)}
        callerName={selectedFile ? selectedFile.name : selectedSample?.name}
      />
    </div>
  );
};
