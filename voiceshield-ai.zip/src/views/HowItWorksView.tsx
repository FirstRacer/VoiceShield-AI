import React from 'react';
import {
  Mic,
  Activity,
  ShieldAlert,
  Lock,
  CheckCircle2,
  XCircle,
  TrendingUp,
} from 'lucide-react';

export const HowItWorksView: React.FC = () => {
  const steps = [
    {
      num: '01',
      title: 'Voice Audio Capture',
      icon: Mic,
      summary: 'Safely receives incoming voice from your microphone during calls, or from an uploaded audio recording.',
      badge: 'Step 1: Input',
    },
    {
      num: '02',
      title: 'Voiceprint & Acoustic Scan',
      icon: Activity,
      summary: 'Inspects vocal fold micro-tremors, natural breathing dynamics, and detects synthetic vocoder phase glitches.',
      badge: 'Step 2: Analysis',
    },
    {
      num: '03',
      title: 'Dynamic Rolling Risk Score',
      icon: TrendingUp,
      summary: 'Continuously averages recent speech chunks. A single isolated pause or cough will never trigger a false alarm.',
      badge: 'Step 3: Scoring',
    },
    {
      num: '04',
      title: 'Real-Time Protection Alert',
      icon: ShieldAlert,
      summary: 'If an AI clone is detected, immediately warns you: "Do not share OTPs, passwords, or transfer money."',
      badge: 'Step 4: Defense',
    },
  ];

  return (
    <div className="space-y-8 animate-in fade-in duration-200 max-w-5xl mx-auto">
      {/* Top Banner */}
      <div className="p-6 sm:p-8 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider bg-lime-100 dark:bg-lime-950/60 text-lime-900 dark:text-lime-300 border border-lime-300 dark:border-lime-800 mb-3">
          VOICE SHIELD AI • LISTEN • DETECT • PROTECT
        </div>
        <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-slate-50 tracking-tight">
          How VoiceShield AI Protects You
        </h2>
        <p className="text-sm sm:text-base text-slate-700 dark:text-slate-300 mt-2 max-w-2xl leading-relaxed">
          Real-time AI voice clones (used in CEO fraud, family emergency scams, and banking impersonation) sound convincing to human ears. VoiceShield AI listens in real-time, spots acoustic differences humans cannot hear, and alerts you before damage is done.
        </p>
      </div>

      {/* 4 Simple Steps */}
      <div>
        <div className="mb-4">
          <h3 className="text-lg font-bold text-slate-900 dark:text-slate-100">
            Simple 4-Step Protection Pipeline
          </h3>
          <p className="text-xs text-slate-600 dark:text-slate-400">
            How incoming sound goes from raw audio to proactive security alert in seconds.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {steps.map((step) => {
            const Icon = step.icon;
            return (
              <div
                key={step.num}
                className="p-5 sm:p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between hover:border-lime-500/50 transition"
              >
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <div className="p-2.5 rounded-xl bg-lime-100 dark:bg-slate-800 text-lime-700 dark:text-lime-400">
                      <Icon className="w-5 h-5" />
                    </div>
                    <span className="text-xs font-mono font-bold px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                      {step.badge}
                    </span>
                  </div>
                  <h4 className="text-base font-bold text-slate-900 dark:text-slate-100 mb-2">
                    {step.title}
                  </h4>
                  <p className="text-xs sm:text-sm text-slate-700 dark:text-slate-300 leading-relaxed font-normal">
                    {step.summary}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Human vs AI Voice Comparison */}
      <div className="p-6 sm:p-8 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
        <h3 className="text-lg font-bold text-slate-900 dark:text-slate-100">
          How We Tell Real Human Voices from AI Clones
        </h3>
        <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400">
          Even the best AI voice generators leave subtle digital fingerprints:
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
          {/* Real Human Voice */}
          <div className="p-5 rounded-xl bg-emerald-50/70 dark:bg-emerald-950/20 border border-emerald-200 dark:border-emerald-900/50 space-y-3">
            <div className="flex items-center gap-2 text-emerald-800 dark:text-emerald-300 font-bold text-sm">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
              <span>Real Human Voice (Bona Fide)</span>
            </div>
            <ul className="space-y-2 text-xs text-slate-800 dark:text-slate-300">
              <li className="flex items-start gap-2">
                <span className="font-semibold text-emerald-700 dark:text-emerald-400">•</span>
                <span><strong>Natural Micro-Jitter:</strong> Tiny, natural fluctuations in vocal cord vibration.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="font-semibold text-emerald-700 dark:text-emerald-400">•</span>
                <span><strong>Breathing & Pauses:</strong> Biological respiration cycles between sentences.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="font-semibold text-emerald-700 dark:text-emerald-400">•</span>
                <span><strong>Organic Vocal Tract Formants:</strong> Natural resonance created by physical throat and mouth anatomy.</span>
              </li>
            </ul>
          </div>

          {/* AI Cloned Voice */}
          <div className="p-5 rounded-xl bg-red-50/70 dark:bg-red-950/20 border border-red-200 dark:border-red-900/50 space-y-3">
            <div className="flex items-center gap-2 text-red-800 dark:text-red-300 font-bold text-sm">
              <XCircle className="w-4 h-4 text-red-600 dark:text-red-400 shrink-0" />
              <span>AI Synthesized Voice (Deepfake Clone)</span>
            </div>
            <ul className="space-y-2 text-xs text-slate-800 dark:text-slate-300">
              <li className="flex items-start gap-2">
                <span className="font-semibold text-red-700 dark:text-red-400">•</span>
                <span><strong>Pitch Rigidity:</strong> Mathematically flat or unnatural pitch steps created by neural networks.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="font-semibold text-red-700 dark:text-red-400">•</span>
                <span><strong>Vocoder Phase Smearing:</strong> Digital noise and high-frequency phase ripples above 4 kHz.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="font-semibold text-red-700 dark:text-red-400">•</span>
                <span><strong>Concatenation Artifacts:</strong> Glitches at phoneme boundary transitions.</span>
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* Privacy Guarantee Box */}
      <div className="p-5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 flex items-start sm:items-center gap-3.5">
        <div className="p-2.5 rounded-xl bg-lime-600 text-white shrink-0">
          <Lock className="w-5 h-5" />
        </div>
        <div>
          <h4 className="text-sm font-bold text-slate-900 dark:text-slate-100">
            Privacy First Architecture
          </h4>
          <p className="text-xs text-slate-700 dark:text-slate-300 mt-0.5 leading-relaxed">
            Your conversations are analyzed in volatile memory for acoustic security markers only. No audio is ever recorded to disk, stored, or sold.
          </p>
        </div>
      </div>

      {/* Bottom Brand Motto */}
      <div className="p-5 rounded-2xl bg-slate-900 text-white border border-slate-800 text-center space-y-1.5">
        <span className="text-[11px] font-mono font-bold uppercase tracking-widest text-lime-400">
          VOICE SHIELD AI
        </span>
        <h4 className="text-base sm:text-lg font-black tracking-tight font-mono">
          LISTEN • DETECT • PROTECT
        </h4>
        <p className="text-xs text-slate-400 max-w-md mx-auto">
          Active authenticity protection against deepfake impersonation and voice cloning fraud.
        </p>
      </div>
    </div>
  );
};
