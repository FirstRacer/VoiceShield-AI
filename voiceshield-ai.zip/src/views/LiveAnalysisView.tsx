import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  RiskLevel,
  AudioChunkResult,
  DetectionSettings,
  AnalysisSession,
} from '../types';
import { AudioAnalysisService } from '../services/audioAnalyzer';
import {
  calculateRiskTrend,
  getRiskExplanation,
  calculateAggregatedOverallRisk,
} from '../services/riskEngine';
import { WaveformCanvas } from '../components/WaveformCanvas';
import { RiskMeter } from '../components/RiskMeter';
import { HighRiskAlertModal } from '../components/HighRiskAlertModal';
import {
  Mic,
  MicOff,
  ShieldAlert,
  AlertTriangle,
  Info,
  Sliders,
  Layers,
  CheckCircle2,
  Cpu,
} from 'lucide-react';

interface LiveAnalysisViewProps {
  settings: DetectionSettings;
  onSessionComplete?: (session: AnalysisSession) => void;
  onOpenSettings: () => void;
  modelStatus?: 'ONLINE' | 'OFFLINE' | 'CHECKING';
}

export const LiveAnalysisView: React.FC<LiveAnalysisViewProps> = ({
  settings,
  onSessionComplete,
  onOpenSettings,
  modelStatus = 'CHECKING',
}) => {
  const isModelOnline = modelStatus !== 'OFFLINE';
  const [isListening, setIsListening] = useState(false);
  const [micPermission, setMicPermission] = useState<'prompt' | 'granted' | 'denied' | 'error'>('prompt');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [serviceError, setServiceError] = useState<string | null>(null);

  const [currentChunk, setCurrentChunk] = useState<AudioChunkResult | null>(null);
  const [chunkHistory, setChunkHistory] = useState<AudioChunkResult[]>([]);
  const [isBackendConnected, setIsBackendConnected] = useState(true);

  // Safety Warning Modal for High Risk
  const [showAlertModal, setShowAlertModal] = useState(false);
  const [alertDismissedForSession, setAlertDismissedForSession] = useState(false);

  const analyzerRef = useRef<AudioAnalysisService | null>(null);
  const startTimeRef = useRef<number>(0);

  // When model is offline, stop listening and clear any active session state
  useEffect(() => {
    if (!isModelOnline && isListening) {
      if (analyzerRef.current) {
        analyzerRef.current.stopMicrophone();
      }
      setIsListening(false);
      setCurrentChunk(null);
      setChunkHistory([]);
    }
  }, [isModelOnline, isListening]);

  useEffect(() => {
    analyzerRef.current = new AudioAnalysisService(settings);
    return () => {
      if (analyzerRef.current) {
        analyzerRef.current.stopMicrophone();
      }
    };
  }, []);

  useEffect(() => {
    if (analyzerRef.current) {
      analyzerRef.current.updateSettings(settings);
    }
  }, [settings]);

  // Robust rolling aggregation: ONE dynamic overall risk score from actual audio chunks
  const aggregatedRisk = useMemo(() => {
    return calculateAggregatedOverallRisk(
      chunkHistory,
      settings.lowThreshold,
      settings.highThreshold,
      2 // Minimum 2 valid speech chunks required before asserting score
    );
  }, [chunkHistory, settings.lowThreshold, settings.highThreshold]);

  const handleStartProtection = async () => {
    if (!isModelOnline) {
      setServiceError('Detection unavailable — connect the W2V2-AASIST backend to analyze audio.');
      return;
    }

    setErrorMessage(null);
    setServiceError(null);
    setAlertDismissedForSession(false);
    setChunkHistory([]);
    setCurrentChunk(null);

    if (!analyzerRef.current) {
      analyzerRef.current = new AudioAnalysisService(settings);
    }

    startTimeRef.current = Date.now();

    const result = await analyzerRef.current.startMicrophone((chunk, backendActive, error) => {
      if (error) {
        setServiceError(error);
        setIsBackendConnected(false);
        return;
      }

      setServiceError(null);
      setIsBackendConnected(backendActive);

      if (chunk) {
        setCurrentChunk(chunk);
        setChunkHistory((prev) => {
          const next = [...prev, chunk];
          return next.slice(-25); // Keep last 25 chunks for timeline
        });
      }
    });

    if (result.success) {
      setIsListening(true);
      setMicPermission('granted');
    } else {
      setIsListening(false);
      setMicPermission('denied');
      setErrorMessage(result.error || 'Failed to start microphone protection.');
    }
  };

  // Trigger high-risk alert modal when aggregated overall risk is confirmed HIGH
  useEffect(() => {
    if (aggregatedRisk.isReady && aggregatedRisk.riskLevel === 'HIGH' && !alertDismissedForSession) {
      setShowAlertModal(true);
    }
  }, [aggregatedRisk.isReady, aggregatedRisk.riskLevel, alertDismissedForSession]);

  const handleStopProtection = () => {
    if (analyzerRef.current) {
      analyzerRef.current.stopMicrophone();
    }
    setIsListening(false);

    // Save evaluated session to history if chunks exist
    if (chunkHistory.length > 0 && onSessionComplete) {
      const duration = Math.max(1, Math.round((Date.now() - startTimeRef.current) / 1000));
      const finalScore = aggregatedRisk.isReady && aggregatedRisk.score !== null
        ? aggregatedRisk.score
        : chunkHistory[chunkHistory.length - 1].syntheticProbability;
      const finalRisk: RiskLevel = aggregatedRisk.isReady
        ? aggregatedRisk.riskLevel
        : 'LOW';
      const exp = getRiskExplanation(finalRisk, finalScore);

      const session: AnalysisSession = {
        id: `live-${Date.now()}`,
        title: 'Live Voice Stream Session',
        timestamp: Date.now(),
        inputType: 'Live Microphone',
        durationSeconds: duration,
        syntheticProbability: finalScore,
        rollingAverage: finalScore,
        riskLevel: finalRisk,
        confidence: aggregatedRisk.confidence || 88.0,
        status: finalRisk === 'HIGH' ? 'High Risk Alert Triggered' : 'Normal',
        recommendation: exp.recommendation,
        chunks: chunkHistory,
        sourceNote: 'SpeechAntiSpoofingBenchmarks/W2V2-AASIST Inference',
      };
      onSessionComplete(session);
    }
  };

  const trend = calculateRiskTrend(chunkHistory);

  // Helper for WaveformCanvas
  const getWaveformData = (data: Uint8Array) => {
    if (analyzerRef.current) {
      analyzerRef.current.getWaveformData(data);
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Top Banner: Real Model Offline Warning or Normal Info */}
      {!isModelOnline ? (
        <div className="p-4 rounded-2xl bg-amber-50/90 dark:bg-amber-950/40 border border-amber-300 dark:border-amber-800 text-amber-900 dark:text-amber-200 flex items-start justify-between flex-wrap gap-3">
          <div className="flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-amber-600 dark:text-amber-400 mt-0.5 flex-shrink-0" />
            <div>
              <h2 className="text-sm font-black uppercase tracking-wider text-amber-900 dark:text-amber-100">
                REAL MODEL OFFLINE
              </h2>
              <p className="text-xs text-amber-800 dark:text-amber-300 mt-0.5">
                Detection unavailable — connect the W2V2-AASIST backend to analyze audio.
              </p>
            </div>
          </div>
          <button
            onClick={onOpenSettings}
            className="px-3 py-1.5 rounded-lg text-xs font-bold bg-amber-600 hover:bg-amber-700 text-white shadow-xs cursor-pointer transition"
          >
            Configure Backend
          </button>
        </div>
      ) : (
        <div className="p-4 rounded-xl bg-slate-100/90 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800 text-xs text-slate-700 dark:text-slate-300 flex items-start gap-3">
          <Info className="w-4 h-4 text-lime-600 dark:text-lime-400 mt-0.5 flex-shrink-0" />
          <div className="space-y-1">
            <div className="font-semibold text-slate-900 dark:text-slate-100">
              VoiceShield AI • Real-Time Voice Authentication
            </div>
            <p className="leading-relaxed text-slate-600 dark:text-slate-400">
              Captures real microphone speech in 1.5-second frames, evaluates acoustic features through the <strong>SpeechAntiSpoofingBenchmarks/W2V2-AASIST</strong> deepfake anti-spoofing pipeline, and calculates a dynamic overall voice risk score.
            </p>
          </div>
        </div>
      )}

      {/* Main Control & Monitor Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Live Audio Stream & Controls (7 Cols) */}
        <div className="lg:col-span-7 space-y-5">
          {/* Audio Monitor Card */}
          <div className="p-5 sm:p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-lg bg-lime-50 dark:bg-lime-950/60 text-lime-600 dark:text-lime-400">
                  <Mic className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="text-base font-bold text-slate-900 dark:text-slate-100">
                    Live Voice Input Protection
                  </h2>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    Continuous 16 kHz stream chunking ({settings.chunkDurationSeconds}s windows) & neural vocoder detection
                  </p>
                </div>
              </div>

              {/* Status Indicator */}
              <div className="flex items-center gap-2">
                <span
                  className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold ${
                    isListening
                      ? 'bg-lime-100 text-lime-800 dark:bg-lime-950/80 dark:text-lime-300 border border-lime-300 dark:border-lime-800'
                      : 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400'
                  }`}
                >
                  <span
                    className={`w-2 h-2 rounded-full ${
                      isListening ? 'bg-lime-500 animate-pulse' : 'bg-slate-400'
                    }`}
                  />
                  {isListening ? 'Stream Active' : 'Standby'}
                </span>
              </div>
            </div>

            {/* Oscilloscope Canvas */}
            <WaveformCanvas
              isActive={isListening}
              getWaveformData={getWaveformData}
              riskLevel={aggregatedRisk.riskLevel}
              height={150}
            />

            {/* Live Audio Telemetry Stats */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1 text-xs">
              <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800">
                <span className="text-[11px] text-slate-500 block">Current Chunk</span>
                <span className="font-mono font-bold text-slate-800 dark:text-slate-200">
                  {currentChunk ? `#${currentChunk.chunkId}` : '—'}
                </span>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800">
                <span className="text-[11px] text-slate-500 block">RMS Voice Energy</span>
                <span className="font-mono font-bold text-slate-800 dark:text-slate-200">
                  {currentChunk
                    ? currentChunk.isSilence
                      ? 'Silence'
                      : `${Math.round(currentChunk.energyLevel * 100)}%`
                    : '—'}
                </span>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800">
                <span className="text-[11px] text-slate-500 block">Spectral Centroid</span>
                <span className="font-mono font-bold text-slate-800 dark:text-slate-200">
                  {currentChunk?.spectralFeatures ? `${currentChunk.spectralFeatures.centroid} Hz` : '—'}
                </span>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800">
                <span className="text-[11px] text-slate-500 block">Inference Engine</span>
                <span className="font-mono font-semibold text-lime-600 dark:text-lime-400 truncate block">
                  {isBackendConnected ? 'W2V2-AASIST' : 'Unavailable'}
                </span>
              </div>
            </div>

            {/* Error Message if Mic Denied */}
            {errorMessage && (
              <div className="p-3 rounded-xl bg-red-50 dark:bg-red-950/50 border border-red-200 dark:border-red-900 text-xs text-red-700 dark:text-red-300 flex items-start gap-2">
                <AlertTriangle className="w-4 h-4 flex-shrink-0 mt-0.5" />
                <span>{errorMessage}</span>
              </div>
            )}

            {/* Backend Service Error if offline */}
            {serviceError && (
              <div className="p-3 rounded-xl bg-amber-50 dark:bg-amber-950/50 border border-amber-200 dark:border-amber-900 text-xs text-amber-800 dark:text-amber-200 flex items-start gap-2">
                <AlertTriangle className="w-4 h-4 flex-shrink-0 mt-0.5 text-amber-600" />
                <span>{serviceError}</span>
              </div>
            )}

            {/* Start / Stop Controls */}
            <div className="flex flex-col sm:flex-row items-center gap-3 pt-2">
              {!isListening ? (
                <button
                  onClick={handleStartProtection}
                  disabled={!isModelOnline}
                  className={`w-full sm:w-auto flex-1 inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl font-bold text-sm shadow-md transition active:scale-[0.99] ${
                    !isModelOnline
                      ? 'bg-slate-200 dark:bg-slate-800 text-slate-400 dark:text-slate-500 cursor-not-allowed border border-slate-300 dark:border-slate-700'
                      : 'bg-lime-600 hover:bg-lime-700 text-white shadow-lime-600/20 hover:shadow-lg cursor-pointer'
                  }`}
                >
                  <Mic className="w-5 h-5" />
                  <span>
                    {!isModelOnline ? 'Model Offline — Connect Backend' : 'Start Voice Protection'}
                  </span>
                </button>
              ) : (
                <button
                  onClick={handleStopProtection}
                  className="w-full sm:w-auto flex-1 inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl font-bold text-sm bg-slate-800 hover:bg-slate-900 text-white shadow-md transition active:scale-[0.99] cursor-pointer"
                >
                  <MicOff className="w-5 h-5" />
                  <span>Stop Voice Protection</span>
                </button>
              )}

              {/* Settings Trigger */}
              <button
                onClick={onOpenSettings}
                className="w-full sm:w-auto px-4 py-3.5 rounded-xl text-xs font-semibold text-slate-700 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 transition inline-flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Sliders className="w-4 h-4" />
                <span>Detection Settings</span>
              </button>
            </div>
          </div>

          {/* Recent Chunks Timeline Table */}
          <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Layers className="w-4 h-4 text-lime-600 dark:text-lime-400" />
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300">
                  Evaluated Speech Chunks Timeline
                </h3>
              </div>
              <span className="text-[11px] font-mono text-slate-400">
                Window: {settings.rollingWindowSize} Chunks
              </span>
            </div>

            {chunkHistory.length === 0 ? (
              <div className="py-8 text-center text-slate-400 text-xs">
                {isListening
                  ? 'Listening for vocal activity... Speak into your microphone.'
                  : 'Start Voice Protection to begin capturing and evaluating audio chunks.'}
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs font-mono">
                  <thead>
                    <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-500 text-[11px]">
                      <th className="py-1.5 px-2">Chunk #</th>
                      <th className="py-1.5 px-2">Model Risk</th>
                      <th className="py-1.5 px-2">Classification</th>
                      <th className="py-1.5 px-2">Confidence</th>
                      <th className="py-1.5 px-2">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60">
                    {[...chunkHistory].reverse().slice(0, 6).map((chunk) => (
                      <tr key={chunk.chunkId} className="hover:bg-slate-50/60 dark:hover:bg-slate-800/30">
                        <td className="py-2 px-2 font-semibold text-slate-800 dark:text-slate-200">
                          #{chunk.chunkId}
                        </td>
                        <td className="py-2 px-2">
                          {chunk.isSilence ? (
                            <span className="text-slate-400 font-normal">Silence</span>
                          ) : (
                            <span
                              className={`font-bold ${
                                chunk.syntheticProbability > 65
                                  ? 'text-red-500'
                                  : chunk.syntheticProbability > 35
                                  ? 'text-amber-500'
                                  : 'text-lime-600'
                              }`}
                            >
                              {chunk.syntheticProbability}%
                            </span>
                          )}
                        </td>
                        <td className="py-2 px-2">
                          <span
                            className={`inline-block px-1.5 py-0.5 rounded text-[10px] font-bold uppercase ${
                              chunk.riskLevel === 'HIGH'
                                ? 'bg-red-100 text-red-700 dark:bg-red-950 dark:text-red-300'
                                : chunk.riskLevel === 'MEDIUM'
                                ? 'bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-300'
                                : 'bg-lime-100 text-lime-700 dark:bg-lime-950 dark:text-lime-300'
                            }`}
                          >
                            {chunk.riskLevel}
                          </span>
                        </td>
                        <td className="py-2 px-2 text-slate-600 dark:text-slate-400">
                          {chunk.confidence}%
                        </td>
                        <td className="py-2 px-2 text-[11px] text-slate-500">
                          {chunk.isSilence ? 'Low energy' : 'Active speech'}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>

        {/* Right Column: Dynamic Overall Risk Score & Safety Directives (5 Cols) */}
        <div className="lg:col-span-5 space-y-5">
          {/* Prominent ONE Final Dynamic Overall Voice Risk Score */}
          <RiskMeter
            overallScore={isModelOnline && aggregatedRisk.isReady ? aggregatedRisk.score : null}
            riskLevel={isModelOnline && aggregatedRisk.isReady ? aggregatedRisk.riskLevel : null}
            confidence={isModelOnline && aggregatedRisk.isReady ? aggregatedRisk.confidence : null}
            trend={trend}
            chunkCount={isModelOnline ? aggregatedRisk.totalChunkCount : 0}
            validChunkCount={isModelOnline ? aggregatedRisk.validChunkCount : 0}
            serviceError={serviceError}
            modelOffline={!isModelOnline}
          />

          {/* High-Risk Safety Directives Card */}
          {isModelOnline && aggregatedRisk.isReady && aggregatedRisk.riskLevel === 'HIGH' ? (
            <div className="p-5 rounded-2xl bg-red-50/90 dark:bg-red-950/40 border-2 border-red-500/80 shadow-md space-y-3 animate-in fade-in">
              <div className="flex items-center gap-2 text-red-600 dark:text-red-400">
                <ShieldAlert className="w-5 h-5" />
                <h3 className="text-sm font-bold uppercase tracking-wider">
                  ⚠️ High Voice Risk Active
                </h3>
              </div>
              <p className="text-xs text-red-800 dark:text-red-200 font-semibold leading-relaxed">
                AI-generated or manipulated voice characteristics were detected in multiple speech chunks.
              </p>
              <div className="p-3 rounded-xl bg-white/80 dark:bg-slate-900/80 border border-red-200 dark:border-red-900 text-xs text-slate-800 dark:text-slate-200 space-y-1.5">
                <div>• <strong>Do not share OTPs, passwords or banking information.</strong></div>
                <div>• <strong>Do not authorize payments or transfers based only on this conversation.</strong></div>
                <div>• <strong>Confirm the request independently before proceeding.</strong></div>
              </div>
              <p className="text-[11px] text-amber-700 dark:text-amber-300 italic">
                Proceeding despite a high-risk voice assessment may expose you to impersonation or fraud.
              </p>
            </div>
          ) : (
            <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-3">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                  <Cpu className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
                    Speech Anti-Spoofing Architecture
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    Model: W2V2-AASIST (wav2vec 2.0 + AASIST Graph Attention)
                  </p>
                </div>
              </div>
              <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                The anti-spoofing engine analyzes raw 16 kHz audio waveforms. In W2V2-AASIST, the model outputs 2-class logits <code className="text-xs font-mono bg-slate-100 dark:bg-slate-800 px-1 py-0.5 rounded">[spoof, bona_fide]</code> where index 1 represents bona fide likelihood. Synthetic risk is computed as <code className="text-xs font-mono bg-slate-100 dark:bg-slate-800 px-1 py-0.5 rounded">(1 - P(Bona Fide)) × 100%</code>.
              </p>
              <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center gap-2 text-xs text-slate-500">
                <CheckCircle2 className="w-3.5 h-3.5 text-lime-500" />
                <span>Strictly zero synthetic simulation data</span>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* High-Risk Safety Alert Modal with CONTINUE WITH CAUTION */}
      <HighRiskAlertModal
        isOpen={showAlertModal}
        probability={aggregatedRisk.score || currentChunk?.syntheticProbability || 0}
        onContinueWithCaution={() => {
          setShowAlertModal(false);
          setAlertDismissedForSession(true);
        }}
        onClose={() => setShowAlertModal(false)}
        callerName="Live Voice Stream"
      />
    </div>
  );
};
