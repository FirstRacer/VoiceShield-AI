/**
 * VoiceShield AI - LISTEN • DETECT • PROTECT
 * Type definitions for voice authenticity and genuine W2V2-AASIST inference pipeline
 */

export type RiskLevel = 'LOW' | 'MEDIUM' | 'HIGH';

export type AppTheme = 'light' | 'medium' | 'dark';

export type ActiveTab =
  | 'dashboard'
  | 'live'
  | 'audio-test'
  | 'history'
  | 'how-it-works'
  | 'tech-stack';

export interface AudioChunkResult {
  chunkId: number;
  timestamp: number;
  syntheticProbability: number | null; // null if silence or model unavailable; otherwise 0%-100% from genuine model
  rollingAverage: number | null;
  riskLevel: RiskLevel;
  confidence: number;
  energyLevel: number;
  isSilence: boolean;
  modelOutput?: {
    bonaFideProbability?: number;
    spoofProbability?: number;
    rawLogits?: [number, number]; // [spoof_logit, bonafide_logit] (W2V2-AASIST convention)
    modelName?: string;
    windowSamples?: number;
  };
  spectralFeatures?: {
    centroid: number; // Hz
    flatness: number; // 0 to 1
    zeroCrossingRate: number;
    phaseArtifacts: number;
  };
  error?: string;
}

export interface AnalysisSession {
  id: string;
  title: string;
  timestamp: number;
  inputType: 'Live Microphone' | 'Audio Upload' | 'Sample Voice Clip';
  durationSeconds: number;
  syntheticProbability: number; // in percent 0-100 from genuine model
  rollingAverage: number;
  riskLevel: RiskLevel;
  confidence: number;
  status: 'Normal' | 'High Risk Alert Triggered' | 'Caution Advised';
  recommendation: string;
  chunks: AudioChunkResult[];
  fileName?: string;
  sourceNote?: string;
}

export interface DetectionSettings {
  lowThreshold: number; // default 35
  highThreshold: number; // default 65
  rollingWindowSize: number; // default 5 chunks
  chunkDurationSeconds: number; // default 1.5s
  apiBaseUrl: string; // e.g. http://localhost:8000 (W2V2-AASIST FastAPI service)
  sensitivity: 'Standard' | 'Conservative' | 'High-Security';
}

export interface ModelStatusInfo {
  realModelOnline: boolean;
  modelLoaded: boolean;
  status: 'ONLINE' | 'OFFLINE';
  backendUrl: string;
  device: string;
  error?: string | null;
  modelName: string;
  message: string;
}

export interface CurrentDetectionState {
  status: 'OFFLINE' | 'WAITING' | 'ANALYZING' | 'READY';
  probability: number | null;
  riskLevel: RiskLevel | null;
  confidence: number | null;
  timestamp?: number;
  source?: string;
  recommendation?: string;
}

