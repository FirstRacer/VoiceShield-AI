import React, { useState } from 'react';
import { DetectionSettings, ModelStatusInfo } from '../types';
import {
  Settings,
  X,
  Sliders,
  Server,
  Cpu,
  RotateCcw,
  Check,
  Radio,
  Loader2,
  CheckCircle2,
  AlertTriangle,
} from 'lucide-react';
import { DEFAULT_SETTINGS } from '../services/riskEngine';

interface SettingsModalProps {
  isOpen: boolean;
  settings: DetectionSettings;
  onSave: (newSettings: DetectionSettings) => void;
  onClose: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  settings,
  onSave,
  onClose,
}) => {
  const [localSettings, setLocalSettings] = useState<DetectionSettings>({ ...settings });
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [isTesting, setIsTesting] = useState(false);
  const [testResult, setTestResult] = useState<ModelStatusInfo | null>(null);

  if (!isOpen) return null;

  const handleSave = () => {
    onSave(localSettings);
    setSavedSuccess(true);
    setTimeout(() => {
      setSavedSuccess(false);
      onClose();
    }, 600);
  };

  const handleReset = () => {
    setLocalSettings({ ...DEFAULT_SETTINGS });
    setTestResult(null);
  };

  const handleTestConnection = async () => {
    setIsTesting(true);
    setTestResult(null);
    try {
      const url = localSettings.apiBaseUrl
        ? `/api/model-status?apiBaseUrl=${encodeURIComponent(localSettings.apiBaseUrl)}`
        : '/api/model-status';

      const res = await fetch(url, { method: 'GET', signal: AbortSignal.timeout(3500) });
      if (res.ok) {
        const data: ModelStatusInfo = await res.json();
        setTestResult(data);
      } else {
        setTestResult({
          realModelOnline: false,
          modelLoaded: false,
          status: 'OFFLINE',
          backendUrl: localSettings.apiBaseUrl || 'http://localhost:8000',
          device: 'none',
          modelName: 'SpeechAntiSpoofingBenchmarks/W2V2-AASIST',
          message: 'Server gateway returned an HTTP error.',
        });
      }
    } catch {
      setTestResult({
        realModelOnline: false,
        modelLoaded: false,
        status: 'OFFLINE',
        backendUrl: localSettings.apiBaseUrl || 'http://localhost:8000',
        device: 'none',
        modelName: 'SpeechAntiSpoofingBenchmarks/W2V2-AASIST',
        message: 'Could not connect to the inference backend at the specified URL.',
      });
    } finally {
      setIsTesting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-xs animate-in fade-in duration-200">
      <div
        role="dialog"
        aria-modal="true"
        className="relative w-full max-w-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-2xl overflow-hidden text-slate-900 dark:text-slate-100 flex flex-col max-h-[90vh]"
      >
        {/* Header */}
        <div className="p-5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
              <Settings className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">
                Risk Engine & Model Configuration
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                W2V2-AASIST real neural model connection, chunking & thresholds
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-6 flex-1 text-xs sm:text-sm">
          {/* 1. Backend & Model Config */}
          <div className="space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-slate-200 dark:border-slate-800">
              <div className="flex items-center gap-2 font-bold text-slate-800 dark:text-slate-200 uppercase tracking-wider text-xs">
                <Server className="w-4 h-4 text-lime-600 dark:text-lime-400" />
                <span>W2V2-AASIST Python/FastAPI Backend</span>
              </div>
              <span className="text-[10px] font-mono text-lime-600 dark:text-lime-400 font-semibold uppercase">
                Zero Simulation
              </span>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                FastAPI Service URL
              </label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={localSettings.apiBaseUrl}
                  onChange={(e) =>
                    setLocalSettings({ ...localSettings, apiBaseUrl: e.target.value })
                  }
                  placeholder="http://localhost:8000"
                  className="flex-1 p-2 text-xs font-mono rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200"
                />
                <button
                  type="button"
                  onClick={handleTestConnection}
                  disabled={isTesting}
                  className="px-3 py-2 rounded-lg text-xs font-bold bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 border border-slate-300 dark:border-slate-700 flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                >
                  {isTesting ? (
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    <Radio className="w-3.5 h-3.5 text-lime-600" />
                  )}
                  <span>Test Connection</span>
                </button>
              </div>
              <p className="text-[11px] text-slate-500 mt-1">
                Point this to the running FastAPI service hosting the W2V2-AASIST model.
              </p>
            </div>

            {/* Test Result Display */}
            {testResult && (
              <div
                className={`p-3 rounded-xl border text-xs space-y-1.5 ${
                  testResult.realModelOnline
                    ? 'bg-lime-50/80 dark:bg-lime-950/30 border-lime-300 dark:border-lime-800 text-lime-800 dark:text-lime-300'
                    : 'bg-amber-50/80 dark:bg-amber-950/30 border-amber-300 dark:border-amber-800 text-amber-800 dark:text-amber-300'
                }`}
              >
                <div className="flex items-center gap-2 font-bold">
                  {testResult.realModelOnline ? (
                    <CheckCircle2 className="w-4 h-4 text-lime-600" />
                  ) : (
                    <AlertTriangle className="w-4 h-4 text-amber-600" />
                  )}
                  <span>Status: REAL MODEL {testResult.status}</span>
                </div>
                <p className="text-[11px] leading-relaxed">{testResult.message}</p>
                <div className="text-[10px] font-mono opacity-80 pt-1 border-t border-current/20 flex gap-3">
                  <span>Device: {testResult.device}</span>
                  <span>Model: {testResult.modelName}</span>
                </div>
              </div>
            )}
          </div>

          {/* 2. Risk Thresholds */}
          <div className="space-y-4">
            <div className="flex items-center gap-2 pb-2 border-b border-slate-200 dark:border-slate-800 font-bold text-slate-800 dark:text-slate-200 uppercase tracking-wider text-xs">
              <Sliders className="w-4 h-4 text-lime-600 dark:text-lime-400" />
              <span>Model Risk Thresholds</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Low Risk Ceiling (&lt; {localSettings.lowThreshold}%)
                </label>
                <input
                  type="range"
                  min="20"
                  max="45"
                  step="5"
                  value={localSettings.lowThreshold}
                  onChange={(e) =>
                    setLocalSettings({ ...localSettings, lowThreshold: Number(e.target.value) })
                  }
                  className="w-full accent-lime-600 cursor-pointer"
                />
                <span className="text-[11px] font-mono text-slate-500">
                  Below {localSettings.lowThreshold}% is LOW RISK
                </span>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  High Risk Floor (&gt; {localSettings.highThreshold}%)
                </label>
                <input
                  type="range"
                  min="55"
                  max="80"
                  step="5"
                  value={localSettings.highThreshold}
                  onChange={(e) =>
                    setLocalSettings({ ...localSettings, highThreshold: Number(e.target.value) })
                  }
                  className="w-full accent-red-600 cursor-pointer"
                />
                <span className="text-[11px] font-mono text-slate-500">
                  Above {localSettings.highThreshold}% triggers HIGH RISK ALERT
                </span>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Rolling Buffer Size
                </label>
                <select
                  value={localSettings.rollingWindowSize}
                  onChange={(e) =>
                    setLocalSettings({
                      ...localSettings,
                      rollingWindowSize: Number(e.target.value),
                    })
                  }
                  className="w-full p-2 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 cursor-pointer"
                >
                  <option value={3}>3 Chunks (Rapid Response, ~4.5s)</option>
                  <option value={5}>5 Chunks (Trimmed Aggregation - Recommended)</option>
                  <option value={7}>7 Chunks (High Smoothing, ~10.5s)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Audio Chunk Cadence
                </label>
                <select
                  value={localSettings.chunkDurationSeconds}
                  onChange={(e) =>
                    setLocalSettings({
                      ...localSettings,
                      chunkDurationSeconds: Number(e.target.value),
                    })
                  }
                  className="w-full p-2 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 cursor-pointer"
                >
                  <option value={1.0}>1.0 Second</option>
                  <option value={1.5}>1.5 Seconds (Optimal)</option>
                  <option value={2.0}>2.0 Seconds</option>
                </select>
              </div>
            </div>
          </div>

          {/* 3. Model Architecture Specs */}
          <div className="p-3.5 rounded-xl bg-slate-100/80 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-800 space-y-2">
            <div className="flex items-center gap-2 text-xs font-bold text-slate-700 dark:text-slate-300">
              <Cpu className="w-4 h-4 text-lime-600" />
              <span>W2V2-AASIST Neural Pipeline Protocol</span>
            </div>
            <div className="grid grid-cols-2 gap-2 text-[11px] text-slate-600 dark:text-slate-400 font-mono">
              <div>Model: W2V2-AASIST (XLS-R 300M + AASIST)</div>
              <div>Input: 16 kHz Mono (~4s / 64,600 samples)</div>
              <div>Logits: [0: Spoof, 1: Bona Fide]</div>
              <div>Formula: P(Spoof) = softmax(logit_0) * 100</div>
            </div>
            <div className="text-[11px] text-slate-500 italic pt-1 border-t border-slate-200 dark:border-slate-800">
              Note: Simulation and fake detection logic are permanently removed. If the FastAPI backend is offline or model weights are not loaded, the UI reports MODEL OFFLINE.
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950/40 flex items-center justify-between">
          <button
            onClick={handleReset}
            className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 transition cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" /> Reset Defaults
          </button>
          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-800 rounded-lg transition cursor-pointer"
            >
              Cancel
            </button>
            <button
              onClick={handleSave}
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-bold bg-lime-600 hover:bg-lime-700 text-white rounded-lg transition shadow-xs cursor-pointer"
            >
              {savedSuccess ? (
                <>
                  <Check className="w-3.5 h-3.5" /> Saved
                </>
              ) : (
                'Save Settings'
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
