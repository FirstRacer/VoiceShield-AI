import React from 'react';
import { RiskLevel } from '../types';
import { ShieldCheck, AlertTriangle, ShieldAlert, TrendingUp, TrendingDown, Minus, Loader2 } from 'lucide-react';

interface RiskMeterProps {
  syntheticProbability?: number;
  overallScore: number | null; // null if waiting or analyzing
  riskLevel: RiskLevel | null;
  confidence?: number | null;
  trend?: 'RISING' | 'FALLING' | 'STABLE';
  chunkCount?: number;
  validChunkCount?: number;
  compact?: boolean;
  serviceError?: string | null;
  statusText?: string;
  modelOffline?: boolean;
}

export const RiskMeter: React.FC<RiskMeterProps> = ({
  overallScore,
  riskLevel,
  confidence = null,
  trend = 'STABLE',
  chunkCount = 0,
  validChunkCount = 0,
  compact = false,
  serviceError = null,
  statusText,
  modelOffline = false,
}) => {
  // If model is offline, display authoritative OFFLINE / NO RESULT state
  if (modelOffline) {
    if (compact) {
      return (
        <div className="flex items-center gap-3 px-3 py-2 rounded-lg border border-amber-300 dark:border-amber-800 bg-amber-50/80 dark:bg-amber-950/40 text-amber-800 dark:text-amber-300">
          <AlertTriangle className="w-4 h-4 flex-shrink-0 text-amber-600" />
          <div className="text-xs font-semibold">
            <span>REAL MODEL OFFLINE — Detection Unavailable</span>
          </div>
        </div>
      );
    }

    return (
      <div className="p-6 rounded-2xl border border-amber-300 dark:border-amber-800 bg-amber-50/80 dark:bg-amber-950/30 text-amber-900 dark:text-amber-200 space-y-3">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl border border-amber-300 dark:border-amber-700/50 bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300">
            <AlertTriangle className="w-6 h-6" />
          </div>
          <div>
            <span className="text-xs uppercase font-mono tracking-widest text-amber-700 dark:text-amber-400 block font-bold">
              REAL MODEL OFFLINE
            </span>
            <div className="text-base font-bold text-amber-900 dark:text-amber-100 mt-0.5">
              NO RESULT
            </div>
          </div>
        </div>
        <p className="text-xs text-amber-800 dark:text-amber-300 leading-relaxed">
          Detection unavailable — connect the W2V2-AASIST backend to analyze audio.
        </p>
      </div>
    );
  }

  if (serviceError) {
    return (
      <div className="p-5 rounded-2xl border border-red-300 dark:border-red-800 bg-red-50/80 dark:bg-red-950/30 text-red-700 dark:text-red-300">
        <div className="flex items-center gap-3">
          <AlertTriangle className="w-5 h-5 flex-shrink-0 text-red-500" />
          <div>
            <span className="font-bold block text-sm">Analysis Service Status:</span>
            <span className="text-xs">{serviceError}</span>
          </div>
        </div>
      </div>
    );
  }

  const isReady = overallScore !== null && riskLevel !== null;

  // Visual config based on risk level
  const effectiveLevel: RiskLevel = riskLevel || 'LOW';
  const config = {
    LOW: {
      label: 'LOW RISK',
      badgeBg: 'bg-lime-100 text-lime-900 dark:bg-lime-950/60 dark:text-lime-300 border-lime-300 dark:border-lime-700/50',
      barColor: 'bg-lime-500',
      icon: ShieldCheck,
      textColor: 'text-lime-600 dark:text-lime-400',
      bgMuted: 'bg-lime-50/80 dark:bg-lime-950/20 border-lime-200 dark:border-lime-900/40',
      subtitle: 'Acoustic parameters align with natural human speech dynamics',
    },
    MEDIUM: {
      label: 'MEDIUM RISK',
      badgeBg: 'bg-amber-100 text-amber-800 dark:bg-amber-950/60 dark:text-amber-300 border-amber-300 dark:border-amber-700/50',
      barColor: 'bg-amber-500',
      icon: AlertTriangle,
      textColor: 'text-amber-600 dark:text-amber-400',
      bgMuted: 'bg-amber-50/80 dark:bg-amber-950/20 border-amber-200 dark:border-amber-900/40',
      subtitle: 'Ambiguous vocal features or codec compression detected',
    },
    HIGH: {
      label: 'HIGH RISK',
      badgeBg: 'bg-red-100 text-red-800 dark:bg-red-950/60 dark:text-red-300 border-red-300 dark:border-red-700/50 animate-pulse',
      barColor: 'bg-red-600',
      icon: ShieldAlert,
      textColor: 'text-red-600 dark:text-red-400',
      bgMuted: 'bg-red-50/90 dark:bg-red-950/30 border-red-300 dark:border-red-900/60',
      subtitle: 'High synthetic / voice cloning probability identified',
    },
  }[effectiveLevel];

  const Icon = config.icon;

  if (compact) {
    return (
      <div className={`flex items-center gap-3 px-3 py-2 rounded-lg border ${isReady ? config.badgeBg : 'bg-slate-100 dark:bg-slate-800 border-slate-200 dark:border-slate-700'}`}>
        <Icon className="w-5 h-5 flex-shrink-0" />
        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between text-xs font-semibold">
            <span>{isReady ? config.label : (statusText || 'Waiting for real model...')}</span>
            <span className="font-mono">
              {overallScore !== null ? `${overallScore}% Voice Risk` : '—'}
            </span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className={`p-6 rounded-2xl border transition-all duration-300 ${isReady ? config.bgMuted : 'bg-slate-50 dark:bg-slate-900/70 border-slate-200 dark:border-slate-800'}`}>
      {/* Prominent Header */}
      <div className="flex items-center justify-between gap-3 flex-wrap mb-5">
        <div className="flex items-center gap-3">
          <div className={`p-2.5 rounded-xl border ${isReady ? config.badgeBg : 'bg-slate-200 dark:bg-slate-800 border-slate-300 dark:border-slate-700 text-slate-500'}`}>
            {!isReady ? (
              chunkCount > 0 ? (
                <Loader2 className="w-6 h-6 animate-spin text-lime-600 dark:text-lime-400" />
              ) : (
                <ShieldCheck className="w-6 h-6 text-slate-400" />
              )
            ) : (
              <Icon className="w-6 h-6" />
            )}
          </div>
          <div>
            <span className="text-xs uppercase font-mono tracking-widest text-slate-500 dark:text-slate-400 block font-semibold">
              OVERALL VOICE RISK
            </span>
            <div className="flex items-center gap-2 mt-0.5">
              {!isReady ? (
                <span className="text-sm font-bold text-slate-600 dark:text-slate-300">
                  {statusText || (chunkCount > 0 ? 'Analyzing voice stream...' : 'Waiting for real model...')}
                </span>
              ) : (
                <span className={`px-2.5 py-0.5 rounded-md text-xs font-black uppercase tracking-wider border ${config.badgeBg}`}>
                  {config.label}
                </span>
              )}
              {validChunkCount > 0 && (
                <span className="text-xs font-mono text-slate-500 dark:text-slate-400">
                  ({validChunkCount} speech {validChunkCount === 1 ? 'chunk' : 'chunks'} evaluated)
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Risk Trend */}
        {isReady && (
          <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/90 dark:bg-slate-900/90 border border-slate-200 dark:border-slate-800 text-xs font-medium text-slate-700 dark:text-slate-300 shadow-xs">
            {trend === 'RISING' && (
              <>
                <TrendingUp className="w-3.5 h-3.5 text-red-500" />
                <span>Trajectory: <strong className="text-red-500">Rising</strong></span>
              </>
            )}
            {trend === 'FALLING' && (
              <>
                <TrendingDown className="w-3.5 h-3.5 text-lime-500" />
                <span>Trajectory: <strong className="text-lime-600">Decreasing</strong></span>
              </>
            )}
            {trend === 'STABLE' && (
              <>
                <Minus className="w-3.5 h-3.5 text-slate-400" />
                <span>Trajectory: <strong>Stable</strong></span>
              </>
            )}
          </div>
        )}
      </div>

      {/* Primary Overall Risk Score Display */}
      <div className="space-y-3 mb-5">
        <div className="flex items-baseline justify-between">
          <div>
            <span className="text-xs font-semibold text-slate-600 dark:text-slate-400 block">
              FINAL OVERALL SYNTHETIC RISK SCORE
            </span>
            <div className="flex items-baseline gap-2 mt-1">
              {!isReady ? (
                <span className="text-2xl sm:text-3xl font-bold font-mono tracking-tight text-slate-400 dark:text-slate-500">
                  {chunkCount > 0 ? 'Analyzing audio...' : 'Waiting for real model...'}
                </span>
              ) : (
                <>
                  <span className={`text-4xl sm:text-5xl font-black font-mono tracking-tight ${config.textColor}`}>
                    {overallScore}%
                  </span>
                  <span className="text-sm font-bold uppercase tracking-wider text-slate-500 font-mono">
                    {riskLevel} RISK
                  </span>
                </>
              )}
            </div>
          </div>

          <div className="text-right">
            <span className="text-xs text-slate-500 dark:text-slate-400 block font-mono">
              Total Chunks: {chunkCount}
            </span>
            {isReady && confidence !== null && confidence !== undefined && (
              <span className="text-xs font-mono font-semibold text-slate-700 dark:text-slate-300">
                Confidence: {confidence}%
              </span>
            )}
          </div>
        </div>

        {/* Progress Track with Zones */}
        <div className="relative h-3.5 w-full bg-slate-200 dark:bg-slate-800 rounded-full overflow-hidden p-0.5">
          {/* Threshold Zone Guides */}
          <div className="absolute inset-0 flex">
            <div className="w-[35%] h-full border-r border-slate-300 dark:border-slate-700/60 bg-lime-500/10" title="Low Risk Zone (<35%)" />
            <div className="w-[30%] h-full border-r border-slate-300 dark:border-slate-700/60 bg-amber-500/10" title="Medium Risk Zone (35%-65%)" />
            <div className="w-[35%] h-full bg-red-500/10" title="High Risk Zone (>65%)" />
          </div>
          {/* Active Fill Bar */}
          <div
            className={`h-full rounded-full transition-all duration-300 ${!isReady ? 'bg-slate-300 dark:bg-slate-700' : config.barColor}`}
            style={{ width: `${!isReady ? 0 : Math.min(100, Math.max(3, overallScore || 0))}%` }}
          />
        </div>

        {/* Zone Labels */}
        <div className="flex justify-between text-[11px] font-mono text-slate-500 dark:text-slate-400 pt-0.5">
          <span>0%</span>
          <span className="text-lime-600 dark:text-lime-400 font-semibold">LOW (&lt;35%)</span>
          <span className="text-amber-600 dark:text-amber-400 font-semibold">MED (35-65%)</span>
          <span className="text-red-600 dark:text-red-400 font-semibold">HIGH (&gt;65%)</span>
          <span>100%</span>
        </div>
      </div>

      {/* Informative Subtitle */}
      <p className="text-xs text-slate-600 dark:text-slate-400 mb-4">
        {!isReady
          ? (chunkCount > 0
              ? 'Sampling incoming acoustic frames to compile genuine model classification...'
              : 'Detection requires the real W2V2-AASIST model online. Scores only appear upon verified inference.')
          : config.subtitle}
      </p>

      {/* Model Spec Tag */}
      <div className="pt-3 border-t border-slate-200/80 dark:border-slate-800/80 flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400 font-mono">
        <span>Model: SpeechAntiSpoofingBenchmarks/W2V2-AASIST</span>
        <span>Zero Synthetic Simulation</span>
      </div>
    </div>
  );
};
