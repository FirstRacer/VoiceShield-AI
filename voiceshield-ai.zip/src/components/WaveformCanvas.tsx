import React, { useEffect, useRef } from 'react';
import { RiskLevel } from '../types';

interface WaveformCanvasProps {
  isActive: boolean;
  getWaveformData?: (data: Uint8Array) => void;
  riskLevel?: RiskLevel;
  height?: number;
  mode?: 'waveform' | 'bars';
}

export const WaveformCanvas: React.FC<WaveformCanvasProps> = ({
  isActive,
  getWaveformData,
  riskLevel = 'LOW',
  height = 140,
  mode = 'waveform',
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);
  const animFrameIdRef = useRef<number | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    const container = containerRef.current;
    if (!canvas || !container) return;

    let width = container.clientWidth || 600;
    canvas.width = width * window.devicePixelRatio;
    canvas.height = height * window.devicePixelRatio;

    const resizeObserver = new ResizeObserver((entries) => {
      for (const entry of entries) {
        if (entry.contentRect.width > 0) {
          width = entry.contentRect.width;
          if (canvasRef.current) {
            canvasRef.current.width = width * window.devicePixelRatio;
            canvasRef.current.height = height * window.devicePixelRatio;
          }
        }
      }
    });
    resizeObserver.observe(container);

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const dataArray = new Uint8Array(512);
    let phase = 0;

    const render = () => {
      const dpr = window.devicePixelRatio || 1;
      const w = canvas.width / dpr;
      const h = canvas.height / dpr;

      ctx.save();
      ctx.scale(dpr, dpr);
      ctx.clearRect(0, 0, w, h);

      // Background subtle grid lines
      ctx.strokeStyle = 'rgba(148, 163, 184, 0.12)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      // Center line
      ctx.moveTo(0, h / 2);
      ctx.lineTo(w, h / 2);
      // Grid lines
      ctx.moveTo(0, h / 4);
      ctx.lineTo(w, h / 4);
      ctx.moveTo(0, (h * 3) / 4);
      ctx.lineTo(w, (h * 3) / 4);
      ctx.stroke();

      if (isActive && getWaveformData) {
        getWaveformData(dataArray);
      } else {
        // Idle gentle breathing sine wave
        phase += 0.04;
        for (let i = 0; i < dataArray.length; i++) {
          const sine = Math.sin(i * 0.05 + phase) * (isActive ? 12 : 3);
          dataArray[i] = 128 + Math.round(sine);
        }
      }

      // Color mapping based on risk level
      let strokeColor = '#65a30d'; // Lime Green (LOW)
      let glowColor = 'rgba(101, 163, 13, 0.3)';
      if (riskLevel === 'MEDIUM') {
        strokeColor = '#d97706'; // Amber
        glowColor = 'rgba(217, 119, 6, 0.25)';
      } else if (riskLevel === 'HIGH') {
        strokeColor = '#dc2626'; // Red
        glowColor = 'rgba(220, 38, 38, 0.3)';
      }

      if (mode === 'waveform') {
        ctx.beginPath();
        ctx.lineWidth = 2;
        ctx.strokeStyle = strokeColor;
        ctx.shadowColor = glowColor;
        ctx.shadowBlur = isActive ? 8 : 0;

        const sliceWidth = w / dataArray.length;
        let x = 0;

        for (let i = 0; i < dataArray.length; i++) {
          const v = dataArray[i] / 128.0;
          const y = (v * h) / 2;

          if (i === 0) {
            ctx.moveTo(x, y);
          } else {
            ctx.lineTo(x, y);
          }
          x += sliceWidth;
        }

        ctx.lineTo(w, h / 2);
        ctx.stroke();
      } else {
        // Frequency bars mode
        const barCount = 48;
        const barWidth = (w / barCount) - 3;
        const step = Math.floor(dataArray.length / barCount);

        for (let i = 0; i < barCount; i++) {
          const val = dataArray[i * step] || 128;
          const normalized = Math.abs(val - 128) / 128;
          const barHeight = Math.max(3, normalized * (h * 0.75));
          const x = i * (barWidth + 3);
          const y = (h - barHeight) / 2;

          ctx.fillStyle = strokeColor;
          ctx.beginPath();
          ctx.roundRect(x, y, barWidth, barHeight, 2);
          ctx.fill();
        }
      }

      ctx.restore();
      animFrameIdRef.current = requestAnimationFrame(render);
    };

    render();

    return () => {
      resizeObserver.disconnect();
      if (animFrameIdRef.current) {
        cancelAnimationFrame(animFrameIdRef.current);
      }
    };
  }, [isActive, getWaveformData, riskLevel, height, mode]);

  return (
    <div ref={containerRef} className="w-full relative overflow-hidden rounded-xl bg-slate-900/5 dark:bg-slate-950/40 border border-slate-200 dark:border-slate-800">
      <div className="absolute top-2 left-3 flex items-center gap-2 pointer-events-none z-10">
        <span className={`inline-block w-2 h-2 rounded-full ${isActive ? 'bg-lime-500 animate-pulse' : 'bg-slate-400'}`} />
        <span className="text-[11px] font-mono tracking-wider font-semibold uppercase text-slate-500 dark:text-slate-400">
          {isActive ? 'Real-Time Audio Stream (Time Domain / 1024-FFT)' : 'Acoustic Monitor Standby'}
        </span>
      </div>
      <canvas
        ref={canvasRef}
        className="w-full block"
        style={{ height: `${height}px` }}
      />
    </div>
  );
};
