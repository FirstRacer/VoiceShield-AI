import React, { useState } from 'react';
import { ActiveTab, AppTheme } from '../types';
import {
  Shield,
  Activity,
  Mic,
  FileAudio,
  History,
  HelpCircle,
  Layers,
  Settings,
  Sun,
  Moon,
  Compass,
  Menu,
  X,
  Radio,
} from 'lucide-react';

interface NavbarProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  theme: AppTheme;
  setTheme: (theme: AppTheme) => void;
  isProtectionActive: boolean;
  onOpenSettings: () => void;
  modelStatus?: 'ONLINE' | 'OFFLINE' | 'CHECKING';
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  theme,
  setTheme,
  isProtectionActive,
  onOpenSettings,
  modelStatus = 'CHECKING',
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Standalone product navigation
  const navItems: { id: ActiveTab; label: string; icon: React.ElementType }[] = [
    { id: 'dashboard', label: 'Dashboard', icon: Activity },
    { id: 'live', label: 'Live Analysis', icon: Mic },
    { id: 'audio-test', label: 'Audio Test', icon: FileAudio },
    { id: 'history', label: 'History', icon: History },
    { id: 'how-it-works', label: 'How It Works', icon: HelpCircle },
    { id: 'tech-stack', label: 'Tech Stack', icon: Layers },
  ];

  const handleNavClick = (tab: ActiveTab) => {
    setActiveTab(tab);
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-40 w-full border-b border-slate-200 dark:border-slate-800/80 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md transition-colors">
      {/* Top micro-bar: Pure VoiceShield Product Slogan */}
      <div className="bg-slate-900 text-slate-300 dark:bg-slate-950 px-4 py-1 text-[11px] font-medium border-b border-slate-800">
        <div className="max-w-7xl mx-auto flex items-center justify-between flex-wrap gap-2">
          <div className="flex items-center gap-2">
            <span className="text-slate-300 font-bold tracking-wider uppercase text-[10px]">
              VOICE SHIELD AI
            </span>
            <span className="text-slate-500">•</span>
            <span className="text-lime-400 font-mono text-[10px] tracking-widest uppercase">
              LISTEN • DETECT • PROTECT
            </span>
          </div>
          <div className="flex items-center gap-3 font-mono text-[10px]">
            {modelStatus === 'ONLINE' ? (
              <span className="inline-flex items-center gap-1.5 text-lime-400 font-semibold">
                <span className="w-1.5 h-1.5 rounded-full bg-lime-400 animate-pulse" />
                REAL MODEL: ONLINE (W2V2-AASIST)
              </span>
            ) : modelStatus === 'OFFLINE' ? (
              <button
                onClick={onOpenSettings}
                className="inline-flex items-center gap-1.5 text-amber-400 hover:text-amber-300 font-semibold cursor-pointer underline decoration-dotted"
                title="Click to configure FastAPI service URL"
              >
                <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />
                REAL MODEL: OFFLINE (Click to Configure)
              </button>
            ) : (
              <span className="inline-flex items-center gap-1.5 text-slate-400">
                <span className="w-1.5 h-1.5 rounded-full bg-slate-400 animate-pulse" />
                CHECKING MODEL BACKEND...
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Main Nav Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4">
        {/* Brand Logo & Tagline */}
        <div
          onClick={() => handleNavClick('dashboard')}
          className="flex items-center gap-3 cursor-pointer group flex-shrink-0"
        >
          <div className="relative flex items-center justify-center w-10 h-10 rounded-xl bg-gradient-to-br from-slate-900 to-slate-800 text-white border border-slate-700 shadow-md group-hover:border-lime-500/50 transition">
            <Shield className="w-5 h-5 text-lime-400" />
            <Radio className="w-3 h-3 text-white absolute bottom-1 right-1" />
          </div>
          <div>
            <div className="flex items-baseline gap-1">
              <span className="font-extrabold tracking-tight text-base sm:text-lg text-slate-900 dark:text-white">
                VOICE<span className="text-lime-600 dark:text-lime-400">SHIELD</span>
              </span>
              <span className="text-[10px] font-mono px-1 rounded bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-bold">
                AI
              </span>
            </div>
            <div className="text-[9px] font-mono tracking-wider text-slate-500 dark:text-slate-400 uppercase -mt-0.5">
              LISTEN • DETECT • PROTECT
            </div>
          </div>
        </div>

        {/* Desktop Navigation Links */}
        <nav className="hidden lg:flex items-center gap-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => handleNavClick(item.id)}
                className={`relative px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
                  isActive
                    ? 'text-lime-800 dark:text-lime-300 bg-lime-50 dark:bg-lime-950/50 border border-lime-200 dark:border-lime-800/60'
                    : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800/60'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>

        {/* Right Action Controls: Protection Pill, Theme Switcher & Settings */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Protection Status Pill */}
          <div className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium bg-lime-50 dark:bg-lime-950/40 text-lime-800 dark:text-lime-300 border border-lime-200 dark:border-lime-900/60">
            <span className={`w-2 h-2 rounded-full ${isProtectionActive ? 'bg-lime-500 animate-ping' : 'bg-lime-500'}`} />
            <span className="text-[11px] font-semibold">Active Guard</span>
          </div>

          {/* Theme Switcher: Light / Medium / Dark */}
          <div className="flex items-center p-0.5 rounded-lg bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs">
            <button
              onClick={() => setTheme('light')}
              title="Light Theme"
              className={`p-1.5 rounded-md transition cursor-pointer ${
                theme === 'light'
                  ? 'bg-white text-slate-900 shadow-xs font-bold'
                  : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
              }`}
            >
              <Sun className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => setTheme('medium')}
              title="Medium Professional Contrast"
              className={`p-1.5 rounded-md transition cursor-pointer ${
                theme === 'medium'
                  ? 'bg-white text-lime-800 shadow-xs font-bold'
                  : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
              }`}
            >
              <Compass className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => setTheme('dark')}
              title="Dark Cybersecurity Theme"
              className={`p-1.5 rounded-md transition cursor-pointer ${
                theme === 'dark'
                  ? 'bg-slate-900 text-lime-400 shadow-xs font-bold'
                  : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
              }`}
            >
              <Moon className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Settings Trigger */}
          <button
            onClick={onOpenSettings}
            className="p-2 rounded-lg text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
            title="Settings & Detection Thresholds"
          >
            <Settings className="w-4 h-4" />
          </button>

          {/* Mobile Menu Hamburger */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden p-2 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
            aria-label="Toggle Navigation"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Navigation Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-4 py-3 space-y-1 animate-in slide-in-from-top-2 duration-150">
          <div className="flex items-center justify-between pb-2 mb-1 border-b border-slate-100 dark:border-slate-800">
            <div className="flex items-center gap-1.5 text-xs text-lime-700 dark:text-lime-400 font-semibold">
              <span className="w-2 h-2 rounded-full bg-lime-500" />
              <span>VoiceShield Active Guard</span>
            </div>
            <span className="text-[10px] font-mono text-slate-400">LISTEN • DETECT • PROTECT</span>
          </div>

          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => handleNavClick(item.id)}
                className={`w-full px-3 py-2.5 rounded-lg text-xs font-semibold flex items-center justify-between transition cursor-pointer ${
                  isActive
                    ? 'text-lime-800 dark:text-lime-300 bg-lime-50 dark:bg-lime-950/60 border border-lime-200 dark:border-lime-800'
                    : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <Icon className="w-4 h-4" />
                  <span>{item.label}</span>
                </div>
              </button>
            );
          })}
        </div>
      )}
    </header>
  );
};
