import React from 'react';
import { ShieldAlert, AlertTriangle, ShieldCheck, X } from 'lucide-react';

interface HighRiskAlertModalProps {
  isOpen: boolean;
  probability: number;
  onContinueWithCaution: () => void;
  onClose?: () => void;
  callerName?: string;
}

export const HighRiskAlertModal: React.FC<HighRiskAlertModalProps> = ({
  isOpen,
  probability,
  onContinueWithCaution,
  onClose,
  callerName,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-xs animate-in fade-in duration-200">
      <div
        role="dialog"
        aria-modal="true"
        className="relative w-full max-w-lg bg-white dark:bg-slate-900 border-2 border-red-500/90 rounded-2xl shadow-2xl p-6 sm:p-7 overflow-hidden text-slate-900 dark:text-slate-100"
      >
        {/* Top Warning Ribbon */}
        <div className="absolute top-0 inset-x-0 h-1.5 bg-gradient-to-r from-red-600 via-amber-500 to-red-600" />

        {/* Close button */}
        {onClose && (
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition"
            aria-label="Close dialog"
          >
            <X className="w-5 h-5" />
          </button>
        )}

        {/* Header with Icon */}
        <div className="flex items-start gap-4 mb-4">
          <div className="p-3 bg-red-100 dark:bg-red-950/70 border border-red-300 dark:border-red-800 text-red-600 dark:text-red-400 rounded-2xl flex-shrink-0 animate-pulse">
            <ShieldAlert className="w-8 h-8" />
          </div>
          <div>
            <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-md text-[11px] font-bold tracking-wider uppercase bg-red-100 dark:bg-red-950/80 text-red-700 dark:text-red-300 border border-red-300 dark:border-red-800 mb-1">
              <AlertTriangle className="w-3.5 h-3.5" /> High Voice Risk Detected
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-red-600 dark:text-red-400 tracking-tight">
              ⚠️ HIGH VOICE RISK DETECTED
            </h2>
            {callerName && (
              <p className="text-xs font-mono text-slate-500 dark:text-slate-400 mt-0.5">
                Active Source: <span className="font-semibold text-slate-800 dark:text-slate-200">{callerName}</span>
              </p>
            )}
          </div>
        </div>

        {/* Model Assessment Description */}
        <div className="p-4 rounded-xl bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900/50 mb-4">
          <p className="text-sm text-slate-800 dark:text-slate-200 leading-relaxed font-semibold">
            AI-generated or manipulated voice characteristics were detected (Synthetic Risk:{' '}
            <strong className="text-red-600 dark:text-red-400 font-mono">{probability}%</strong>).
          </p>
        </div>

        {/* Explicit Safety Warnings */}
        <div className="space-y-2.5 mb-5">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
            Critical Safety Directives:
          </h3>
          <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-800 text-xs text-slate-700 dark:text-slate-300 space-y-2">
            <div className="flex items-start gap-2">
              <span className="text-red-500 font-bold">•</span>
              <span><strong>Do not share OTPs, passwords or banking information.</strong></span>
            </div>
            <div className="flex items-start gap-2">
              <span className="text-red-500 font-bold">•</span>
              <span><strong>Do not authorize payments or transfers based only on this conversation.</strong></span>
            </div>
            <div className="flex items-start gap-2">
              <span className="text-red-500 font-bold">•</span>
              <span><strong>Confirm the request independently before proceeding.</strong></span>
            </div>
          </div>
        </div>

        {/* Caution Disclosure */}
        <div className="p-3 rounded-xl bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-900/40 text-xs text-amber-800 dark:text-amber-300 mb-5">
          <strong>Risk Notice:</strong> Proceeding despite a high-risk voice assessment may expose you to impersonation or fraud. VoiceShield provides a security warning inside this application and does not physically block external cellular calls or banking networks.
        </div>

        {/* Primary Action Button */}
        <div className="flex flex-col sm:flex-row items-stretch gap-3">
          <button
            onClick={onContinueWithCaution}
            className="w-full inline-flex items-center justify-center gap-2 px-5 py-3.5 rounded-xl font-bold text-sm bg-red-600 hover:bg-red-700 text-white shadow-lg shadow-red-600/25 transition active:scale-[0.99] cursor-pointer"
          >
            <ShieldCheck className="w-4 h-4" />
            <span>CONTINUE WITH CAUTION</span>
          </button>
        </div>

        {/* Core Security Philosophy */}
        <p className="text-center text-[10px] font-mono uppercase tracking-widest text-slate-400 dark:text-slate-500 mt-4">
          VOICE SHIELD AI • LISTEN • DETECT • PROTECT
        </p>
      </div>
    </div>
  );
};
