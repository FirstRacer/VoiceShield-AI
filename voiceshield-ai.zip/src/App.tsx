import React, { useState, useEffect } from 'react';
import { ActiveTab, AppTheme, AnalysisSession, DetectionSettings, CurrentDetectionState } from './types';
import { DEFAULT_SETTINGS } from './services/riskEngine';
import { Navbar } from './components/Navbar';
import { SettingsModal } from './components/SettingsModal';
import { DashboardView } from './views/DashboardView';
import { LiveAnalysisView } from './views/LiveAnalysisView';
import { AudioTestView } from './views/AudioTestView';
import { HistoryView } from './views/HistoryView';
import { HowItWorksView } from './views/HowItWorksView';
import { TechStackView } from './views/TechStackView';
import { Shield } from 'lucide-react';

export default function App() {
  // Theme state persisted in localStorage
  const [theme, setTheme] = useState<AppTheme>(() => {
    const saved = localStorage.getItem('voiceshield_theme');
    if (saved === 'light' || saved === 'medium' || saved === 'dark') {
      return saved as AppTheme;
    }
    return 'light';
  });

  const [activeTab, setActiveTab] = useState<ActiveTab>('dashboard');
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [modelStatus, setModelStatus] = useState<'ONLINE' | 'OFFLINE' | 'CHECKING'>('CHECKING');

  // Real model detection state — authoritative; never shows stale or fake risk data
  const [currentDetection, setCurrentDetection] = useState<CurrentDetectionState>({
    status: 'WAITING',
    probability: null,
    riskLevel: null,
    confidence: null,
    timestamp: null,
  });

  // Session history state — starts empty, only populated by actual evaluations
  const [sessions, setSessions] = useState<AnalysisSession[]>(() => {
    try {
      const saved = localStorage.getItem('voiceshield_sessions');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) {
          // Strictly purge any legacy mock/synthetic 90.2% entries from previous versions
          const cleaned = parsed.filter(
            (s: AnalysisSession) =>
              s.syntheticProbability !== 90.2 && s.syntheticProbability !== 90
          );
          if (cleaned.length !== parsed.length) {
            localStorage.setItem('voiceshield_sessions', JSON.stringify(cleaned));
          }
          return cleaned;
        }
      }
    } catch {
      // ignore
    }
    return [];
  });

  // Settings state persisted in localStorage
  const [settings, setSettings] = useState<DetectionSettings>(() => {
    try {
      const saved = localStorage.getItem('voiceshield_settings');
      if (saved) {
        return { ...DEFAULT_SETTINGS, ...JSON.parse(saved) };
      }
    } catch {
      // ignore
    }
    return DEFAULT_SETTINGS;
  });

  // Check real model backend status
  const checkModelStatus = async () => {
    try {
      const url = settings.apiBaseUrl
        ? `/api/model-status?apiBaseUrl=${encodeURIComponent(settings.apiBaseUrl)}`
        : '/api/model-status';
      const res = await fetch(url, { signal: AbortSignal.timeout(3000) });
      if (res.ok) {
        const data = await res.json();
        setModelStatus(data.realModelOnline ? 'ONLINE' : 'OFFLINE');
      } else {
        setModelStatus('OFFLINE');
      }
    } catch {
      setModelStatus('OFFLINE');
    }
  };

  useEffect(() => {
    checkModelStatus();
    const interval = setInterval(checkModelStatus, 30000);
    return () => clearInterval(interval);
  }, [settings.apiBaseUrl]);

  // When model is offline or checking, authoritative reset of detection result
  useEffect(() => {
    if (modelStatus !== 'ONLINE') {
      setCurrentDetection({
        status: 'OFFLINE',
        probability: null,
        riskLevel: null,
        confidence: null,
        timestamp: null,
      });
    } else {
      // Transitioning to ONLINE: initialize as "Waiting for real model..." if not already ready
      setCurrentDetection((prev) => {
        if (prev.status === 'OFFLINE') {
          return {
            status: 'WAITING',
            probability: null,
            riskLevel: null,
            confidence: null,
            timestamp: null,
          };
        }
        return prev;
      });
    }
  }, [modelStatus]);

  // Apply theme to html data-theme attribute and class list
  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
      document.documentElement.classList.remove('theme-medium');
    } else if (theme === 'medium') {
      document.documentElement.classList.add('dark');
      document.documentElement.classList.add('theme-medium');
    } else {
      document.documentElement.classList.remove('dark');
      document.documentElement.classList.remove('theme-medium');
    }
    localStorage.setItem('voiceshield_theme', theme);
  }, [theme]);

  // Persist settings
  const handleSaveSettings = (newSettings: DetectionSettings) => {
    setSettings(newSettings);
    localStorage.setItem('voiceshield_settings', JSON.stringify(newSettings));
  };

  // Add session to history — only accept when real model is ONLINE and valid real inference result is present
  const handleSessionComplete = (newSession: AnalysisSession) => {
    if (
      modelStatus === 'ONLINE' &&
      newSession.syntheticProbability !== null &&
      typeof newSession.syntheticProbability === 'number'
    ) {
      setCurrentDetection({
        status: 'READY',
        probability: newSession.syntheticProbability,
        riskLevel: newSession.riskLevel,
        confidence: newSession.confidence,
        timestamp: Date.now(),
      });

      setSessions((prev) => {
        const next = [newSession, ...prev];
        localStorage.setItem('voiceshield_sessions', JSON.stringify(next.slice(0, 50)));
        return next;
      });
    }
  };

  const handleClearHistory = () => {
    setSessions([]);
    localStorage.removeItem('voiceshield_sessions');
  };

  return (
    <div className="min-h-screen flex flex-col bg-[var(--bg-primary)] text-[var(--text-primary)] transition-colors duration-200">
      {/* Top Navbar */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        theme={theme}
        setTheme={setTheme}
        isProtectionActive={true}
        onOpenSettings={() => setIsSettingsOpen(true)}
        modelStatus={modelStatus}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-6 sm:py-8">
        {activeTab === 'dashboard' && (
          <DashboardView
            sessions={sessions}
            setActiveTab={setActiveTab}
            isProtectionActive={true}
            modelStatus={modelStatus}
            currentDetection={currentDetection}
            onOpenSettings={() => setIsSettingsOpen(true)}
          />
        )}

        {activeTab === 'live' && (
          <LiveAnalysisView
            settings={settings}
            onSessionComplete={handleSessionComplete}
            onOpenSettings={() => setIsSettingsOpen(true)}
            modelStatus={modelStatus}
          />
        )}

        {activeTab === 'audio-test' && (
          <AudioTestView
            settings={settings}
            onSessionComplete={handleSessionComplete}
            onOpenSettings={() => setIsSettingsOpen(true)}
            modelStatus={modelStatus}
          />
        )}

        {activeTab === 'history' && (
          <HistoryView
            sessions={sessions}
            onClearHistory={handleClearHistory}
            modelStatus={modelStatus}
          />
        )}

        {activeTab === 'how-it-works' && (
          <HowItWorksView />
        )}

        {activeTab === 'tech-stack' && (
          <TechStackView />
        )}
      </main>

      {/* Settings Modal */}
      <SettingsModal
        isOpen={isSettingsOpen}
        settings={settings}
        onSave={handleSaveSettings}
        onClose={() => setIsSettingsOpen(false)}
      />

      {/* Professional Product Footer */}
      <footer className="w-full border-t border-slate-200 dark:border-slate-800/80 bg-white/60 dark:bg-slate-900/60 mt-auto text-xs text-slate-500 dark:text-slate-400">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-4">
          <div className="flex items-center justify-between flex-wrap gap-3">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-md bg-slate-900 text-white flex items-center justify-center">
                <Shield className="w-3.5 h-3.5 text-lime-400" />
              </div>
              <span className="font-extrabold text-slate-800 dark:text-slate-200 tracking-wider">
                VOICE SHIELD AI
              </span>
            </div>

            {/* Product Slogan */}
            <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 font-mono text-[11px] font-bold tracking-widest uppercase">
              <span>LISTEN • DETECT • PROTECT</span>
            </div>
          </div>

          <div className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed border-t border-slate-100 dark:border-slate-800/60 pt-3">
            <p>
              <strong>Security Advisory:</strong> VoiceShield AI provides real-time acoustic analysis and risk assessment to detect synthetic speech and AI-generated voice cloning. VoiceShield provides an advisory security barrier inside this application and does not physically block external cellular calls, SMS OTPs, or external bank accounts.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
